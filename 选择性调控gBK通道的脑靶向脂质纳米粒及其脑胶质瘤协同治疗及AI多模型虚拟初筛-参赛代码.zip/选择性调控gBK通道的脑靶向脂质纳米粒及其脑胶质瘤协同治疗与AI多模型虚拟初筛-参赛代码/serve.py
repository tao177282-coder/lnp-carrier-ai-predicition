"""Local-only static demo and optional Python prediction API. No deployment."""
import argparse,json
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from src.inference import predict_batch,catalog
from src.results_io import ROOT
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT/'web'),**kwargs)
    def json_response(self,data,status=200):
        content=json.dumps(data,ensure_ascii=False,allow_nan=False).encode('utf8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(content)));self.end_headers();self.wfile.write(content)
    def do_GET(self):
        if self.path=='/api/catalog':return self.json_response(catalog())
        return super().do_GET()
    def do_POST(self):
        if self.path!='/api/predict':return self.json_response({'error':'Unknown route'},404)
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<=65536:raise ValueError('Request size must be 1–65536 bytes')
            return self.json_response({'records':predict_batch(json.loads(self.rfile.read(n)))})
        except (ValueError,TypeError,KeyError) as e:return self.json_response({'error':str(e)},400)
def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8781);args=p.parse_args()
    print(f'Local demo: http://127.0.0.1:{args.port}/',flush=True)
    ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
if __name__=='__main__':main()
