"""Order results within the same model, model version and assay conditions."""
import argparse,json,math
from pathlib import Path
from src.inference import sort_records
from src.results_io import ROOT,HEADERS,read_json,write_csv,flattened

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,default=ROOT/'results/predictions.json')
    p.add_argument('--model',default='n2a-delivery')
    p.add_argument('--direction',choices=['asc','desc'],default='desc')
    p.add_argument('--output',type=Path,default=ROOT/'results/screened.csv')
    args=p.parse_args();records=read_json(args.input);eligible=[];unranked=[]
    for row in records:
        pred=row.get('predictions',{}).get(args.model)
        # Reference curves vary experimental conditions, not formulation design.
        # Weak BBB/N2a viability outputs remain available but not formal screening.
        if not pred or pred.get('value') is None or pred.get('status')=='reference' or args.model in {'bbb-transport','n2a-compatibility'}:
            unranked.append(row);continue
        if not isinstance(pred['value'],(int,float)) or not math.isfinite(pred['value']):raise ValueError('Nonfinite prediction')
        eligible.append(row)
    grouped=sort_records(eligible,args.model,args.direction);output=[]
    for g in grouped['groups']:
        previous=None;rank=0
        for index,row in enumerate(g['records'],1):
            value=row['predictions'][args.model]['value']
            if previous is None or value!=previous:rank=index
            previous=value
            one=dict(row,predictions={args.model:row['predictions'][args.model]})
            detail=flattened([one])[0];detail.update(同条件排序=rank,排序定位='仅在当前模型及条件内排序；不是疗效排序')
            if args.model=='lnp-size':detail['排序定位']='仅按粒径数值排序；不存在粒径越小越好的默认结论'
            output.append(detail)
    for row in unranked:
        if args.model not in row.get('predictions',{}):continue
        detail=flattened([dict(row,predictions={args.model:row['predictions'][args.model]})])[0]
        detail.update(同条件排序='',排序定位='保留结果；不参与正式载体筛选');output.append(detail)
    write_csv(args.output,output,['同条件排序','排序定位']+HEADERS)
    print(json.dumps(dict(rows=len(output),comparable_groups=len(grouped['groups']),model=args.model,missing_values_imputed=False),ensure_ascii=False))
if __name__=='__main__':main()
