// MC3固定文献配方的条件参考支路；旧模型不接受未知MC3独热编码。
// 所有锚点均为图表刻度估读，不代表新的独立配方或湿实验真值。
export const isMC3=(catalog,selected,input)=>input.headgroup_precursor==='DLin-MC3-DMA'&&selected.some(k=>catalog.mc3.bio_keys.includes(k));

export function mc3Fields(catalog,key,input){
  const m=catalog.models.find(m=>m.key===key), config=catalog.mc3.fields;
  const fields=m.fields.filter(f=>f.key==='headgroup_precursor');
  const number=(key,minimum,maximum)=>({key,...config[key],minimum,maximum});
  if(key==='n2a-delivery'||key==='n2a-compatibility')fields.push({key:'mc3_formulation',...config.mc3_formulation});
  if(key==='n2a-delivery'){
    fields.push({key:'mc3_mode',...config.mc3_mode});
    const mode=input.mc3_mode||'dose-24h';
    if(mode==='dose-24h')fields.push(number('mc3_dose_ng',3,30),number('mc3_time_h',24,24));
    else if(mode==='time-60ng')fields.push(number('mc3_dose_ng',60,60),number('mc3_time_h',6,48));
    else throw new Error('请选择MC3表达参考条件。');
  }else if(key==='n2a-compatibility')fields.push(number('mc3_dose_ng',15,60),number('mc3_time_h',24,24));
  return fields;
}

export function curveValue(curve,x){
  if(typeof x!=='number'||!Number.isFinite(x)||x<curve.minimum||x>curve.maximum)throw new Error('MC3仅支持所选文献范围内的条件插值。');
  const segment=curve.segments.find(s=>s.lo<=x&&x<=s.hi);
  const tx=curve.x_transform==='log10'?Math.log10(x):x;
  const y=segment.slope*tx+segment.intercept;
  return curve.y_transform==='log10'?10**y:y;
}

export function mc3Result(catalog,parameters,key,input){
  const m=catalog.models.find(m=>m.key===key);
  if(!['n2a-delivery','n2a-compatibility'].includes(key))return {
    value:null,unit:'',name:m.name,endpoint:'MC3：暂无可用终点模型',purpose:'数据不足，不参与比较',
    status:'unavailable',meaning:'现有材料没有支持这一终点的MC3配套训练数据，保留空值。',
    protocol:'MC3专用支路；未调用其他材料或其他细胞的模型替代。',comparison_key:null,
    source_type:null,doi:null,notes:['不会将缺失结果设为0、1或100。']};
  const delivery=key==='n2a-delivery',timed=delivery&&input.mc3_mode==='time-60ng';
  const id=delivery?(timed?'haase_expression_time':'haase_expression_dose'):'haase_viability_dose';
  const c=parameters.mc3_reference[id];
  const value=curveValue(c,timed?input.mc3_time_h:input.mc3_dose_ng);
  const protocol=`Haase 2024；MC3:DSPC:胆固醇:PEG-DMG=50:10:38.5:1.5 mol%；N/P=3；总脂质:mRNA=10:1质量比；N2a 10000 cells/well；FLuc mRNA ${input.mc3_dose_ng} ng/well；${input.mc3_time_h} h；${c.figure}。`;
  return {value,unit:c.unit,name:m.name,endpoint:delivery?'MC3固定配方FLuc表达（扣除HBG背景）':'MC3固定配方MTT代谢活力（HBG归一化）',
    purpose:'固定配方条件参考，不用于新配方排名',status:'reference',
    meaning:delivery?'N2a的荧光素酶表达读数；不是相对MC3倍数、细胞摄取率或脑递送效率。':'相对HBG对照的MTT活力，可超过100%；不是原PBS参照模型，不等同体内安全性。',
    protocol,comparison_key:`MC3|${id}|${c.version}|${input.mc3_dose_ng}|${input.mc3_time_h}`,
    source_type:c.source_type,doi:c.doi,figure:c.figure,
    notes:['图表估读锚点上的区间内插值；仅1个独立配方，无跨配方预测能力验证。',
      '只使用MC3固定文献配方；未使用或推断粒径、Zeta、pKa、包封率的响应效应。',
      '不同剂量、时间、文献或检测定义的数值分组保存，不合并为载体优劣排名。']};
}
