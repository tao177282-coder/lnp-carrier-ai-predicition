// 固定权重推理适配器；MC3走单独的文献条件参考支路。
import {isMC3,mc3Fields,mc3Result} from './mc3-reference.mjs';
// 数值等价验证由 verification/verify.mjs 与原Python输出逐项完成。
const modelMap = catalog => new Map(catalog.models.map(m=>[m.key,m]));
const invalid = message => { throw new Error(message); };

export function inputUnion(catalog, selected, inputs={}) {
  const models=modelMap(catalog), fields=new Map();
  if(!Array.isArray(selected)||!selected.length||new Set(selected).size!==selected.length||selected.some(k=>!models.has(k)))invalid('请选择有效且不重复的模型。');
  for(const key of selected){
    const m=models.get(key), mc3=isMC3(catalog,selected,inputs), fs=mc3?mc3Fields(catalog,key,inputs):[...m.fields];
    if(key==='bbb-transport'&&!mc3){
      const ctx=m.contexts[inputs.context];
      if(!ctx)invalid('请从下拉框选择BBB实验条件。');
      for(const [k,[minimum,maximum]] of Object.entries(ctx.ranges))fs.push({key:k,...catalog.fields[k],type:'number',minimum,maximum});
    }
    for(const f of fs){
      if(!fields.has(f.key))fields.set(f.key,structuredClone(f));
      else if(f.type==='number'){
        const old=fields.get(f.key);old.minimum=Math.max(old.minimum,f.minimum);old.maximum=Math.min(old.maximum,f.maximum);
      }else{
        const old=fields.get(f.key);old.options=old.options.filter(o=>f.options.some(v=>v.value===o.value));
      }
    }
  }
  return fields;
}

export function validateBatch(catalog,payload){
  if(!payload||typeof payload!=='object'||Array.isArray(payload))invalid('请求格式错误。');
  const rows=payload.formulations,selected=payload.models,names=new Set();
  if(!Array.isArray(rows)||rows.length<1||rows.length>5)invalid('每批只允许提交1～5组配方。');
  const clean=rows.map(r=>{
    if(!r||typeof r.name!=='string'||!r.name.trim()||r.name.length>60)invalid('载体编号需为1～60个字符。');
    const name=r.name.trim();if(names.has(name))invalid('同一批的载体编号不能重复。');names.add(name);
    if(!r.inputs||typeof r.inputs!=='object'||Array.isArray(r.inputs))invalid('配方参数格式错误。');
    const fields=inputUnion(catalog,selected,r.inputs),inputs={};
    if(Object.keys(r.inputs).some(k=>!fields.has(k)))invalid('包含所选模型不需要的参数。');
    for(const [k,f] of fields){
      let v=r.inputs[k];
      if(f.type==='select'){
        if(!f.options.some(o=>o.value===v))invalid(`${name}：${f.label}必须从固定选项选择。`);
      }else{
        if(typeof v!=='number'&&typeof v!=='string')invalid(`${name}：请填写${f.label}。`);
        if(typeof v==='string'&&!/^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(v.trim()))invalid(`${name}：${f.label}必须为数值。`);
        v=Number(v);
        if(!Number.isFinite(v)||v<f.minimum||v>f.maximum)invalid(`${name}：${f.label}须在${f.minimum}～${f.maximum}内。`);
      }
      inputs[k]=v;
    }
    return {name,inputs};
  });
  return {models:[...selected],formulations:clean};
}

function encoded(input,p){
  // DictVectorizer列顺序和所有标准化参数均来自原artifact。
  return p.feature_names.map((name,i)=>{
    const split=name.indexOf('=');
    const value=split<0?Number(input[name]):Number(input[name.slice(0,split)]===name.slice(split+1));
    return (value-p.mean[i])/p.scale[i];
  });
}

export function leafIndices(input,p){
  const x=encoded(input,p).map(Math.fround);
  return p.trees.map(t=>{
    let i=0;
    while(t.left[i]!==-1)i=x[t.feature[i]]<=t.threshold[i]?t.left[i]:t.right[i];
    return i;
  });
}

export function predictValue(catalog,parameters,key,input){
  const meta=modelMap(catalog).get(key),p=parameters[key];
  if(!meta||!p)invalid('模型不存在。');
  if(input.headgroup_precursor==='DLin-MC3-DMA'){
    if(!catalog.mc3.bio_keys.includes(key))return null;
    const own=Object.fromEntries([...inputUnion(catalog,[key],input).keys()].map(k=>[k,input[k]]));
    const checked=validateBatch(catalog,{models:[key],formulations:[{name:'MC3',inputs:own}]}).formulations[0].inputs;
    return mc3Result(catalog,parameters,key,checked).value;
  }
  const needed=inputUnion(catalog,[key],input);
  const own=Object.fromEntries([...needed.keys()].map(k=>[k,input[k]]));
  const checked=validateBatch(catalog,{models:[key],formulations:[{name:'prediction',inputs:own}]}).formulations[0].inputs;
  let value;
  if(p.kind==='bbb_ridge'){
    const x=p.numeric.map((k,i)=>(checked[k]-p.mean[i])/p.sd[i]);
    const native=meta.context_mapping[checked.context];
    for(const levels of Object.values(p.levels))for(const label of levels)x.push(Number(native===label));
    let z=p.coef[0];for(let i=0;i<x.length;i++)z+=x[i]*p.coef[i+1];
    z=z*p.ysd+p.ymean;
    value=100/(1+Math.exp(-Math.min(700,Math.max(-700,z))));
  }else{
    if(p.kind==='ridge'){
      const x=encoded(checked,p);value=p.intercept;
      for(let i=0;i<x.length;i++)value+=x[i]*p.coef[i];
    }else{
      // sklearn树在标准化后将输入转为float32，叶值仍使用float64。
      const leaves=leafIndices(checked,p);value=0;
      for(let i=0;i<leaves.length;i++)value+=p.trees[i].value[leaves[i]];
      value/=p.trees.length;
    }
    if(p.transform==='log1p')value=Math.expm1(value);
  }
  if(!Number.isFinite(value))invalid('模型未返回有效数值。');
  return value;
}

export function runBatch(catalog,parameters,payload){
  const clean=validateBatch(catalog,payload),models=modelMap(catalog);
  return clean.formulations.map(r=>{
    const predictions={};
    for(const key of clean.models){
      if(isMC3(catalog,clean.models,r.inputs)){
        predictions[key]=mc3Result(catalog,parameters,key,r.inputs);continue;
      }
      const m=models.get(key),value=predictValue(catalog,parameters,key,r.inputs);
      let meaning,protocol=m.protocol,comparison=m.version;
      if(key==='lnp-size')meaning='预测该固定材料体系下的水动力学粒径。粒径更小不自动代表递送效果更好。';
      else if(key.includes('delivery'))meaning='相对MC3参照的荧光素酶表达倍数；1表示与参照相当。不是细胞摄取率、BBB穿透率或基因敲低率。';
      else if(key.includes('compatibility'))meaning='相对PBS参照的MTT活力；100%表示与参照相当，可超过100%。不等同体内安全性。';
      else{
        meaning='所选体外屏障条件下的示踪物转运比例；脂质示踪不等同核酸跨脑效率，不用于筛选决策。';
        const ctx=m.contexts[r.inputs.context];protocol=ctx.description+` 观察时间：${r.inputs.time_h} h。`;comparison+=`|${r.inputs.context}|${r.inputs.time_h}`;
      }
      const notes=['仅供既定材料与实验条件下的虚拟实验参考，尚无独立湿实验验证。'];
      if(value<0)notes.push('预测值低于物理合理下限，原值保留，不应自动采纳。');
      if(key.includes('compatibility'))notes.push('当前原记录未核实实验剂量。');
      predictions[key]={value,unit:m.unit,name:m.name,endpoint:m.endpoint,purpose:m.purpose,meaning,protocol,comparison_key:comparison,notes};
    }
    return {...r,selected_models:clean.models,predictions};
  });
}

export function sortRecords(catalog,records,model,direction='desc'){
  if(!modelMap(catalog).has(model)||!['asc','desc'].includes(direction))invalid('排序参数错误。');
  const groups=new Map(),missing=[];
  for(const r of records){
    const p=r.predictions?.[model];if(!p||typeof p.value!=='number'||!Number.isFinite(p.value)){missing.push(r);continue;}
    if(!groups.has(p.comparison_key))groups.set(p.comparison_key,[]);
    groups.get(p.comparison_key).push(r);
  }
  return {groups:[...groups.entries()].sort((a,b)=>a[0].localeCompare(b[0])).map(([,rows])=>{
    rows.sort((a,b)=>(a.predictions[model].value-b.predictions[model].value)*(direction==='asc'?1:-1));
    return {protocol:rows[0].predictions[model].protocol,records:rows};
  }),missing};
}
