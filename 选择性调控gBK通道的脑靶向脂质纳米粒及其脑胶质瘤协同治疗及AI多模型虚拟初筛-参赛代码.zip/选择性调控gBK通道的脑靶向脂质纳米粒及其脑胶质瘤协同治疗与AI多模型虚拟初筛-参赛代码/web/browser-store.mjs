// 只保存当前浏览器中的记录；没有共享数据库或上传预测输入的接口。
import {runBatch,sortRecords,validateBatch} from './inference.mjs';
export const DATABASE='lnp-share-lab-v1';
let opening;
export function openDatabase(){
  if(!opening)opening=new Promise((resolve,reject)=>{
    const r=indexedDB.open(DATABASE,1);
    r.onupgradeneeded=()=>{
      if(!r.result.objectStoreNames.contains('records'))r.result.createObjectStore('records',{keyPath:'id'});
      if(!r.result.objectStoreNames.contains('batches'))r.result.createObjectStore('batches',{keyPath:'id'});
    };
    r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(new Error('当前浏览器无法保存记录，请允许网站使用本地存储。'));
  });
  return opening;
}
const request=r=>new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
const complete=t=>new Promise((resolve,reject)=>{t.oncomplete=resolve;t.onabort=()=>reject(t.error||new Error('保存已中断'));t.onerror=()=>reject(t.error);});
async function history(){const db=await openDatabase();return (await request(db.transaction('records').objectStore('records').getAll())).sort((a,b)=>b.created_at.localeCompare(a.created_at)||a.id.localeCompare(b.id));}

export function createBrowserAPI(catalog,parameters){
  let busy=false;
  return async(path,payload)=>{
    if(path==='/api/catalog')return catalog;
    if(path==='/api/history')return {records:await history()};
    if(path==='/api/sort'){
      const all=await history(),chosen=payload.ids?all.filter(r=>payload.ids.includes(r.id)):all;
      return sortRecords(catalog,chosen,payload.model,payload.direction);
    }
    if(busy)throw new Error('请等待当前批次完成。');
    busy=true;
    try{
      const db=await openDatabase();
      if(path==='/api/predict'){
        const clean=validateBatch(catalog,payload),id=payload.request_id;
        if(typeof id!=='string'||!/^[0-9a-f-]{36}$/i.test(id))throw new Error('请求编号无效。');
        const canonical=JSON.stringify(clean);
        const old=await request(db.transaction('batches').objectStore('batches').get(id));
        if(old){
          if(old.canonical!==canonical)throw new Error('同一请求编号不能提交不同配方。');
          if(old.revoked)throw new Error('此批次已有记录被删除，请重新发起预测。');
          return old.response;
        }
        const rows=runBatch(catalog,parameters,clean),now=new Date().toISOString();
        rows.forEach(r=>Object.assign(r,{id:crypto.randomUUID(),batch_id:id,created_at:now}));
        const response={records:rows,batch_id:id};
        const t=db.transaction(['records','batches'],'readwrite'),done=complete(t);
        rows.forEach(r=>t.objectStore('records').add(r));
        t.objectStore('batches').add({id,canonical,response});await done;return response;
      }
      if(path==='/api/clear'){
        if(payload.confirm!==true)throw new Error('请确认清空历史。');
        const t=db.transaction(['records','batches'],'readwrite'),done=complete(t);
        t.objectStore('records').clear();t.objectStore('batches').clear();await done;return {ok:true};
      }
      if(path==='/api/delete'){
        const t=db.transaction(['records','batches'],'readwrite'),done=complete(t),store=t.objectStore('records');
        const r=store.get(payload.id);
        r.onsuccess=()=>{
          const old=r.result;
          if(old){const batches=t.objectStore('batches'),b=batches.get(old.batch_id);b.onsuccess=()=>{if(b.result)batches.put({...b.result,revoked:true,response:null});};}
          store.delete(payload.id);
        };
        await done;return {ok:true};
      }
      throw new Error('未知操作。');
    }finally{busy=false;}
  };
}
