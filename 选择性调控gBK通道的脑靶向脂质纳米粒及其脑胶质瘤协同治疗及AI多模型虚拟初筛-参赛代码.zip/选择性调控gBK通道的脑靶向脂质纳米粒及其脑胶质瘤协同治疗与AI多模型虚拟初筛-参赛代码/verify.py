"""Small, meaningful runtime checks using existing literature examples only.

Invalid-input checks are software tests, not experimental or training samples.
"""
import copy,csv,hashlib,json,math,subprocess,sys
from pathlib import Path
from src.inference import predict_batch,validate_batch,catalog,sort_records
from src.results_io import ROOT,read_json,write_json,run

def main():
    cases=[]
    for name in ['four_candidates','size_example','bbb_example','mc3_reference']:
        payload=read_json(ROOT/'data/examples'/f'{name}.json');records=predict_batch(payload)
        cases.append(dict(case=name,payload=payload,records=records))
    models={m['key'] for m in catalog()['models']}
    assert models=={'lnp-size','n2a-delivery','bend3-compatibility','bend3-delivery','n2a-compatibility','bbb-transport'}
    assert (ROOT/'models/model-parameters.json').read_bytes()==(ROOT/'web/model-parameters.json').read_bytes()
    assert (ROOT/'models/catalog.json').read_bytes()==(ROOT/'web/catalog.json').read_bytes()
    mc3=cases[-1]['records'][0]['predictions']
    assert mc3['bend3-delivery']['value'] is None and mc3['bend3-compatibility']['value'] is None
    assert mc3['n2a-delivery']['status']=='reference' and mc3['n2a-compatibility']['value']>100
    invalid=[];base=cases[0]['payload']
    renamed=copy.deepcopy(base);renamed['formulations'][0]['name']='renamed-TD4'
    assert run(renamed)[0]['submission']['selection_with_known_truth'] is True
    for value in [None,'',False,True,float('nan'),float('inf'),999]:
        p=copy.deepcopy(base);p['formulations'][0]['inputs']['particle_size']=value
        try:validate_batch(p)
        except (TypeError,ValueError):invalid.append('numeric')
        else:raise AssertionError('Invalid numeric input accepted')
    for value in ['DLin-MC3-DMA glycosylated','gBK-siRNA','unknown']:
        p=copy.deepcopy(base);p['formulations'][0]['inputs']['headgroup_precursor']=value
        try:validate_batch(p)
        except (TypeError,ValueError):invalid.append('unsupported_material')
        else:raise AssertionError('Unsupported chemistry accepted')
    for count in [0,6]:
        p=copy.deepcopy(base);p['formulations']=[dict(base['formulations'][0],name=str(i)) for i in range(count)]
        try:validate_batch(p)
        except ValueError:invalid.append('batch_limit')
        else:raise AssertionError('Batch limit ignored')
    for item in read_json(ROOT/'data/manifests/training_sources.json'):
        path=ROOT/item['packaged_csv'];assert hashlib.sha256(path.read_bytes()).hexdigest()==item['packaged_sha256']
        with path.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
        assert len(rows)==item['rows'] and len({r['split_group'] for r in rows})==item['independent_formulations']
    write_json(ROOT/'logs/python_runtime_cases.json',cases)
    report=dict(status='passed',enabled_models=len(models),existing_example_cases=len(cases),invalid_input_checks=len(invalid),data_hash_checks=6,
        purpose='Software/data integrity checks only, not biological predictive accuracy',missing_values_imputed=False)
    write_json(ROOT/'logs/runtime_qa.json',report);print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
