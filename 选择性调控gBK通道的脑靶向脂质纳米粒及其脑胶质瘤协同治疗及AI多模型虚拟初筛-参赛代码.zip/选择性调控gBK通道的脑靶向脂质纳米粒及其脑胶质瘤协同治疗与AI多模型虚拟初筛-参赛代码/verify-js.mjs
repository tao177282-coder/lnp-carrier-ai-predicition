// Optional JS/Python parity QA. Existing literature examples; no new science data.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {runBatch} from './web/inference.mjs';
const read=p=>JSON.parse(fs.readFileSync(new URL(p,import.meta.url),'utf8'));
const catalog=read('./models/catalog.json'),parameters=read('./models/model-parameters.json');
const tests=read('./logs/python_runtime_cases.json');let checked=0,maxError=0;
for(const t of tests){
  const actual=runBatch(catalog,parameters,t.payload);
  for(let i=0;i<actual.length;i++)for(const key of t.payload.models){
    const a=actual[i].predictions[key],p=t.records[i].predictions[key];
    // The established browser core omits the explicit "predicted" status on
    // ordinary predictions; the Python wrapper makes this default explicit.
    assert.equal(a.status??'predicted',p.status);
    if(p.value==null)assert.equal(a.value,null);
    else{const error=Math.abs(a.value-p.value);assert.ok(error<1e-10+1e-10*Math.abs(p.value));maxError=Math.max(maxError,error);}
    checked++;
  }
}
const report={status:'passed',predictions_checked:checked,max_absolute_difference:maxError,purpose:'Software equivalence only; not biological validation'};
fs.writeFileSync(new URL('./logs/js_parity_qa.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
