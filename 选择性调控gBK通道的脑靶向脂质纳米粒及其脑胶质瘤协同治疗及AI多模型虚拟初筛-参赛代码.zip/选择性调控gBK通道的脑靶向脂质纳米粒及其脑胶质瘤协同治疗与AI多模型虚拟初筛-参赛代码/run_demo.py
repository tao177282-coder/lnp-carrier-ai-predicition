"""One-command fit → inference → within-protocol screening → verification demo."""
import argparse,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser();p.add_argument('--with-training',action='store_true',help='Also fit/evaluate a small real-data Ridge example (requires training dependencies).');a=p.parse_args()
    commands=[['train.py','--model','mc3-reference','--out','results/mc3-refit'],['predict.py'],['screen.py'],['verify.py']]
    if a.with_training:commands.insert(1,['train.py','--demo','--out','results/small_training_demo'])
    for command in commands:subprocess.run([sys.executable,*command],cwd=ROOT,check=True)
    print('Done. results/results.csv and results/screened.csv are reproducible literature-example replays, not blind validation.')
if __name__=='__main__':main()
