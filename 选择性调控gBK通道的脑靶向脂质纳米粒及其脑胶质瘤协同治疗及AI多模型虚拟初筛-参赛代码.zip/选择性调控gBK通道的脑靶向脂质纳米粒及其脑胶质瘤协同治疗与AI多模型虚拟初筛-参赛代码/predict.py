"""Read 1–5 candidate formulations and generate the competition results.csv."""
import argparse,json,sys
from pathlib import Path
from src.results_io import read_json,run,flattened,write_csv,write_json,ROOT

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,default=ROOT/'data/examples/four_candidates.json')
    p.add_argument('--provenance',type=Path,default=ROOT/'data/examples/four_candidates_provenance.json')
    p.add_argument('--output',type=Path,default=ROOT/'results/results.csv')
    p.add_argument('--json',type=Path,default=ROOT/'results/predictions.json')
    args=p.parse_args()
    try:
        records=run(read_json(args.input),read_json(args.provenance) if args.provenance.exists() else [])
        write_csv(args.output,flattened(records));write_json(args.json,records)
        print(json.dumps(dict(candidates=len(records),predictions=sum(len(r['predictions']) for r in records),output=args.output.name,external_validation=False),ensure_ascii=False))
    except (ValueError,TypeError,KeyError,OSError) as e:
        print('Input/output error: '+str(e),file=sys.stderr);return 2
    return 0
if __name__=='__main__':raise SystemExit(main())
