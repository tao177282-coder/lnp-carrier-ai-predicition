"""Optional training schema regression checks; no model update or fitting."""
import copy,json
from src.training.runner import ROOT,read,validation
from src.results_io import write_json
configs=json.loads((ROOT/'models/training-configs.json').read_text(encoding='utf8'))
checks=[]
for key,cfg in configs.items():
    validation(read(ROOT/'data/processed'/f'{key}.csv'),key,cfg);checks.append('valid:'+key)
key='n2a-delivery';cfg=configs[key]
for wrong in ['bend3-compatibility','bend3-delivery']:
    try:validation(read(ROOT/'data/processed'/f'{wrong}.csv'),key,cfg)
    except ValueError:checks.append('reject_wrong_endpoint:'+wrong)
    else:raise AssertionError('Wrong endpoint accepted')
rows=read(ROOT/'data/processed/n2a-delivery.csv');rows[0]['particle_size']='NaN'
try:validation(rows,key,cfg)
except ValueError:checks.append('reject_nonfinite_input')
else:raise AssertionError('NaN feature accepted')
write_json(ROOT/'logs/training_schema_qa.json',dict(status='passed',checks=checks));print('Training schema QA passed.')
