# LNP文献数据虚拟筛选原型

面向第一届全球大学生生命科学挑战赛，赛道4、本科生组、华东赛区。课题目标是**gBK靶向siRNA的LNP递送**。本包提供已经完成的文献数据模型及调用原型，供初步载体筛选与可复现性核查。

必须区分课题目标与模型终点：文献中的N2a/bEnd.3模型预测的是**FLuc mRNA表达或MTT代谢活力**，不是gBK siRNA敲低率；BBB模型是指定体外示踪物转运，不是体内胶质瘤疗效。课题组湿实验数据未用于外部验证。未将糖基化MC3、任意新脂质或gBK构建体加入训练域。

## 快速运行：推理不需要额外依赖

已验证环境：Python **3.12.14**，Windows 11 x86-64，CPU。无CUDA、显卡驱动、API密钥或联网推理要求。现代浏览器可运行本地页面。打包测试机器为Intel64 Family 6 Model 197；并非最低硬件要求。建议至少4GB可用内存。操作命令在本目录执行；路径使用相对路径。

```bash
python predict.py
python screen.py --model n2a-delivery
python run_demo.py
python serve.py --port 8781
```

打开 `http://127.0.0.1:8781/` 可查看现有完整HTML前端。页面在浏览器执行等价JS推理；可选Python接口为 `POST /api/predict`。仅绑定本机，不会发布公网网站。页面源文件保持现有最终版，含1–5组配方、联合输入校验、浏览器历史、同条件比较功能。本包没有带入原有预测历史。

`run_demo.py` 完成：真实MC3文献估读点的有界参考曲线拟合 → 已有文献四候选推理 → 同模型同条件排序 → 参数/数据校验。无合成实验训练数据。四候选TD4、MK2、MK6、MK1曾结合已知实验结果筛选，是**非盲回代演示**，不能据此报告发现成功率或外部准确率。

## 输入与输出

```bash
python predict.py --input data/examples/four_candidates.json --output results/results.csv --json results/predictions.json
python screen.py --input results/predictions.json --model n2a-delivery --direction desc --output results/screened.csv
python predict.py --input data/examples/mc3_reference.json --output results/mc3_reference.csv --json results/mc3_reference_predictions.json
```

输入JSON格式与现有网页完全一致：`models` 是模型键列表，`formulations` 是最多5条 `{name, inputs}`。可用字段、精确上下限、固定下拉选项在 `models/catalog.json` 和 `ModelCard.md`，不可自行扩展范围。`data/examples` 同时提供粒径和BBB独立调用示例。

`results.csv` 为UTF-8 BOM、英文逗号分隔的标准CSV，包含候选编号、所属赛道、完整组分说明、实验名称、预测值、单位、模型/运行版本、状态、比较组、条件、输入、来源DOI及备注。一个候选在每个终点各占一行，便于避免把单位不同的输出混成一个得分。没有支持的模型输出保持空白；不补0、1或100。

排序仅限同一模型版本和相同实验条件。N2a相容性、BBB及MC3参考曲线保留结果、不列正式筛选名次；粒径排序仅是数值顺序，不意味着越小越好。没有人工加权“综合治疗分数”。默认生物学模型不自动接收粒径模型的预测值。

## 最终模型与复训

`models/model-parameters.json` 是实际推理的最终参数；`web/model-parameters.json` 为同一文件的前端副本，两者哈希一致。只启用6个最终模型，加MC3专用参考分支；没有PDI或包封率输出模型。包封率仍是两项递送模型的有效输入。

本项目实际训练过岭回归、Extra Trees、随机森林等传统机器学习模型，不是调用语言模型预测实验结果。科学核心位于 `src/training`；标准库推理引擎位于 `src/inference.py`。最终算法及参数来自既有模型，打包没有修改其统计逻辑。

可选训练依赖严格锁定在 `requirements-training.txt`。推理不需安装这些包：

```bash
python -m pip install -r requirements-training.txt
python train.py --model all
python train.py --demo --out results/small_training_demo
python run_demo.py --with-training
python train.py --model n2a-delivery --nested-selection --out results/nested_reproduction
```

- `--model all` 使用**已经选定的最终超参数**重新拟合6个模型，并进行按配方分组的检查。重建参数写在新结果目录，绝不覆盖交付权重。最终参数记录在 `models/training-configs.json`。已在提交环境完整运行，重建预测与原权重最大绝对差约3.55×10⁻¹⁵，属于浮点误差。
- 这次固定超参数的CV是复现检查，**不能替代原来的嵌套选择CV**。原评价和分组选择日志在 `models/evaluation-records.json`、`logs/original`。
- `--nested-selection` 提供4个重建模型原有的嵌套分组特征/算法选择完整入口。N2a相容性旧最终核心和BBB原最终训练实现亦保留；冻结参数重训入口已实际验证。当前不重复执行全部耗时的嵌套搜索来抬高指标。
- `--demo` 只对4个真实、已知结果候选拟合小型岭回归示例，输出独立训练/分组日志。其分数没有科学泛化意义，不安装进正式模型，也不替代原评价。
- `python train.py --model mc3-reference` 只拟合1种固定MC3配方的3条条件参考曲线，不输出伪造的跨配方R²。

依赖版本变化可能改变树结构或浮点运算。6模型冻结参数重训在当前CPU环境约数秒至数十秒；具体耗时见 `logs/reproduction`。嵌套搜索需更多时间。所有路径均可移植，不依赖原电脑目录。

## 数据、范围与许可

`data/processed` 包含本轮用户授权打包的必要派生数值CSV；数值、缺失、来源、原文实测/图表估读标记均保留，只移除了个人绝对路径。`data/manifests/training_sources.json` 记录原始派生文件及打包文件哈希、DOI、字段与配方数。无PDF、SI原件、Source Data原始工作簿、课题湿实验数据或个人历史。文献归属及许可说明见 `data/README.md`；未声称出版社资料或提取数据采用开放许可。

连续测量、重复孔、同配方多时间点按 `split_group` 保持同折；BBB为43条记录、21独立配方，MC3为11个条件均值、1配方，不能把行数当作独立配方数。已知真值筛选四候选的偏倚明确披露。没有隐藏测试集、独立湿实验测试集或预训练生物学模型。

## 软件验证与交付目录

```bash
python verify.py
# 可选：Node.js 24.19.0，仅做JS/Python一致性检查；前端实际使用浏览器。
node verify-js.mjs
```

验证覆盖6模型、4种已有数据调用示例、空值/未知材料/批次数校验、数据哈希、前后端22条预测一致性。`logs/runtime_qa.json` 和 `logs/js_parity_qa.json` 记录结果，**这些是软件正确性检查，不是生物学准确率**。

核心目录：`src`代码，`models`最终权重和Model Card元数据，`web`原样网页，`data`派生数据与来源说明，`results`候选CSV示例，`logs`真实评价/复训/QA，`notebooks`可执行流程Notebook。根目录入口覆盖附件5要求；没有调用第三方AI API的运行依赖。开发时使用了AI编程辅助，核心算法依赖见 `THIRD_PARTY.md`。
