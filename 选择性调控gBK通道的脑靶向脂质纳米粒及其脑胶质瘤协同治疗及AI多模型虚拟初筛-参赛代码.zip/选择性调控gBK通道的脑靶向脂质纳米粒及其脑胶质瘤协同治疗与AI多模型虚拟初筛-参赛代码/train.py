"""Train/reproduce final models without overwriting any delivered model weights."""
import argparse,csv,json,hashlib,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model',default='all',choices=['all','n2a-delivery','bend3-delivery','bend3-compatibility','n2a-compatibility','lnp-size','bbb-transport','mc3-reference'])
    p.add_argument('--data',type=Path,help='Optional one-model CSV. Missing values are not filled.')
    p.add_argument('--out',type=Path,default=ROOT/'results/retrained')
    p.add_argument('--demo',action='store_true',help='Only 4 real, previously selected Wang candidates; not a valid accuracy study.')
    p.add_argument('--nested-selection',action='store_true',help='Original nested selection for one of the 4 rebuilt models (slower).')
    args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    if args.model=='mc3-reference':
        from src.mc3 import fit_curve,evaluate_curve
        specs={'haase_expression_dose':('log10','log10'),'haase_expression_time':('identity','log10'),'haase_viability_dose':('identity','identity')};curves={}
        for name,(xt,yt) in specs.items():
            with (ROOT/'data/examples'/f'{name}.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
            if len({r['formulation_id'] for r in rows})!=1:raise ValueError('Reference curve cannot mix formulations')
            curves[name]=fit_curve(rows,xt,yt)
            curves[name].update(doi=rows[0]['doi'],figure=rows[0]['figure'],source_type=rows[0]['source_type'],independent_formulations=1,R2=None,Spearman=None)
        (args.out/'mc3-reference-fit.json').write_text(json.dumps(curves,ensure_ascii=False,indent=2),encoding='utf8')
        print('Fitted 3 bounded reference curves from 11 graph-estimated means; one formula; no generalization R2.');return
    try:from src.training.runner import train_one,nested_rebuilt,dump
    except ImportError as e:raise SystemExit('Training requires: python -m pip install -r requirements-training.txt\n'+str(e))
    configs=json.loads((ROOT/'models/training-configs.json').read_text(encoding='utf8'))
    selected=['n2a-delivery'] if args.demo else list(configs) if args.model=='all' else [args.model]
    if args.data and len(selected)!=1:raise SystemExit('--data requires exactly one model')
    if args.nested_selection:
        if len(selected)!=1 or args.demo:raise SystemExit('Choose one rebuilt model and do not combine nested selection with demo')
        key=selected[0];nested_rebuilt(key,args.data or ROOT/'data/processed'/f'{key}.csv',args.out);return
    bundle=json.loads((ROOT/'models/model-parameters.json').read_text(encoding='utf8'));logs=[]
    for key in selected:
        data=(ROOT/'data/examples/demo_training.csv') if args.demo else args.data or ROOT/'data/processed'/f'{key}.csv'
        parameter,log=train_one(key,data,args.out,args.demo);bundle[key]=parameter;logs.append(log)
        print(json.dumps(dict(model=key,rows=log['n_rows'],groups=log['n_formulations'],replay_max_abs_difference=log['replay_max_abs_deviation_from_delivered_weights'],demo_only=args.demo),ensure_ascii=False),flush=True)
    dump(args.out/'training_log.json',logs)
    # Demo weights are intentionally not installed into the operational bundle.
    if not args.demo:dump(args.out/'model-parameters.json',bundle)
if __name__=='__main__':main()
