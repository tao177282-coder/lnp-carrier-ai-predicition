"""Portable training wrapper around the final, unchanged estimator algorithms.

The default uses the already selected final hyperparameters, so its CV is a
reproducibility check, not a replacement for the archived nested-selection CV.
Full nested selection remains available for the four rebuilt models.
"""
import csv,hashlib,importlib,json,math,platform,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).parent/'rebuilt'))
sys.path.insert(0,str(Path(__file__).parent/'bbb'))
import numpy as np
import scipy,sklearn,joblib
from scipy.stats import spearmanr
import modeling,data_io,specifications
import bbb_model
from src.training import n2a_compatibility as old
from src.inference import _legacy_value

def read(path):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def dump(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
def export_estimator(model,est,num,cat,transform):
    out=dict(feature_names=model.vectorizer.get_feature_names_out().tolist(),numeric=num,categorical=cat,
             mean=model.scaler.mean_.tolist(),scale=model.scaler.scale_.tolist(),transform=transform)
    if hasattr(est,'coef_'):out.update(kind='ridge',coef=est.coef_.tolist(),intercept=float(est.intercept_))
    else:
        trees=[]
        for estimator in est.estimators_:
            t=estimator.tree_;trees.append(dict(left=t.children_left.tolist(),right=t.children_right.tolist(),feature=t.feature.tolist(),threshold=t.threshold.tolist(),value=t.value[:,0,0].tolist()))
        out.update(kind='forest',trees=trees)
    return out

def validation(rows,key,cfg):
    fields=(specifications.SPECS[cfg['native']]['sets'][cfg['config']['features']][0]+specifications.SPECS[cfg['native']]['sets'][cfg['config']['features']][1]) if cfg['engine']=='rebuilt' else (['particle_size','apparent_pka','headgroup_precursor'] if cfg['engine']=='n2a_compatibility' else ['particle_size','time_h','context'])
    target='target_percent' if cfg['engine']=='bbb' else 'target'
    if not rows:raise ValueError('Empty dataset')
    categorical={'headgroup_precursor','helper','context'}
    metadata=json.loads((ROOT/'models/catalog.json').read_text(encoding='utf8'))
    bbb_contexts=set(next(m for m in metadata['models'] if m['key']=='bbb-transport')['context_mapping'].values())
    for r in rows:
        if not r.get('doi') or not r.get('split_group'):raise ValueError('Missing provenance or formulation group')
        if any(r.get(f) in ['',None] for f in fields+[target]):raise ValueError('Missing feature/target; no imputation')
        if not math.isfinite(float(r[target])):raise ValueError('Nonfinite target')
        if any(not math.isfinite(float(r[f])) for f in fields if f not in categorical):raise ValueError('Nonfinite numeric input')
        if cfg['engine']=='rebuilt':
            spec=specifications.SPECS[cfg['native']]
            if r.get('model_id')!=cfg['native'] or r.get('target_unit')!=spec['unit']:raise ValueError('Wrong experimental endpoint/model_id or target unit')
            if not r.get('target_source_type') or not r.get('target_source_locators'):raise ValueError('Missing target provenance')
        elif cfg['engine']=='n2a_compatibility':
            if r.get('task')!='compatibility__N2a' or r.get('family')!='compatibility' or r.get('target_unit')!='%':raise ValueError('N2a compatibility requires its own MTT endpoint and % unit')
        else:
            if r.get('minimal_eligible')!='1' or r.get('context') not in bbb_contexts:raise ValueError('Unvalidated BBB endpoint/context')
            if r.get('endpoint_unit') not in ['%','percent'] and r.get('y_unit')!='%':raise ValueError('BBB requires an explicitly percentage-normalized endpoint')
        if float(r[target])<0:raise ValueError('Negative experimental response requires source verification')
        if 'headgroup_precursor' in fields and r['headgroup_precursor'] not in specifications.HEADGROUPS:raise ValueError('Unknown lipid category; MC3 uses its separate fixed-recipe branch')
        if 'helper' in fields and r['helper'] not in ['DOPE','DSPC']:raise ValueError('Unknown helper lipid')
        if cfg['engine']=='bbb' and not 0<float(r[target])<100:raise ValueError('BBB logit requires 0 < transport < 100')
    if len({r['sample_id'] for r in rows})!=len(rows):raise ValueError('Duplicate sample ID')
    if len({r['split_group'] for r in rows})<3:raise ValueError('At least 3 independent groups required for this training entry')
    return fields,target

def fit(rows,cfg):
    if cfg['engine']=='rebuilt':return modeling.FittedModel(cfg['native'],cfg['config']).fit(rows)
    if cfg['engine']=='n2a_compatibility':return old.ScreeningModel(cfg['config'],'compatibility').fit(rows)
    return bbb_model.fitted(rows,['particle_size','time_h'],cfg['config']['method'],cfg['config']['param'])
def pred(model,rows,cfg):return bbb_model.predict_rows(model,rows) if cfg['engine']=='bbb' else model.predict(rows)
def folds(rows,cfg):
    if cfg['engine']=='bbb':return bbb_model.split(rows)
    if cfg['engine']=='n2a_compatibility':return old.split(rows)
    return data_io.grouped_folds(rows)

def train_one(key,data,outdir,demo=False):
    started=time.perf_counter();cfg=json.loads((ROOT/'models/training-configs.json').read_text(encoding='utf8'))[key]
    rows=read(data);fields,target=validation(rows,key,cfg);oof=[];audit=[]
    for fold,(tr,va) in enumerate(folds(rows,cfg),1):
        train_groups={r['split_group'] for r in tr};test_groups={r['split_group'] for r in va}
        assert not train_groups & test_groups
        model=fit(tr,cfg);values=pred(model,va,cfg)
        audit.append(dict(fold=fold,train_groups=sorted(train_groups),test_groups=sorted(test_groups)))
        for row,value in zip(va,values):oof.append(dict(sample_id=row['sample_id'],split_group=row['split_group'],fold=fold,target=float(row[target]),prediction=float(value)))
    y=np.array([r['target'] for r in oof]);p=np.array([r['prediction'] for r in oof]);den=float(((y-y.mean())**2).sum())
    metric=dict(R2=None if den==0 else 1-float(((y-p)**2).sum())/den,Spearman=float(spearmanr(y,p).statistic) if np.ptp(p)>0 and np.ptp(y)>0 else None,MAE=float(abs(y-p).mean()))
    final=fit(rows,cfg);out=Path(outdir)/key;out.mkdir(parents=True,exist_ok=True)
    if cfg['engine']=='bbb':
        final.save(out/'single-model.json');parameter=json.loads((out/'single-model.json').read_text(encoding='utf8'));parameter['kind']='bbb_ridge'
    elif cfg['engine']=='rebuilt':parameter=export_estimator(final,final.estimator,final.numeric,final.categorical,cfg['transform'])
    else:parameter=export_estimator(final,final.model,final.num,final.cat,cfg['transform'])
    dump(out/'single-model.json',parameter)
    # Comparing full-data fits verifies reproduction of published weights; it is
    # not a held-out prediction evaluation and must not be called accuracy.
    previous=[];catalog=json.loads((ROOT/'models/catalog.json').read_text(encoding='utf8'))
    native_to_public={v:k for k,v in next(m for m in catalog['models'] if m['key']=='bbb-transport')['context_mapping'].items()}
    for r in rows:
        inp={f:float(r[f]) if f not in ['headgroup_precursor','helper','context'] else r[f] for f in fields}
        if key=='bbb-transport':inp['context']=native_to_public[inp['context']]
        previous.append(_legacy_value(key,inp))
    deviation=float(np.max(np.abs(np.asarray(previous)-pred(final,rows,cfg))))
    log=dict(model=key,mode='four-known-candidates-demo' if demo else 'final-frozen-config-reproduction',n_rows=len(rows),n_formulations=len({r['split_group'] for r in rows}),config=cfg,
        input_sha256=hashlib.sha256(Path(data).read_bytes()).hexdigest(),validation_scope='grouped CV with already selected fixed hyperparameters; NOT original nested-selection CV or independent external validation',metrics=metric,
        replay_max_abs_deviation_from_delivered_weights=deviation,external_validation=False,demo_only=demo,
        random_seeds=dict(group_split=42,rebuilt_estimator=20260928,n2a_compatibility_estimator=20260927),
        versions=dict(Python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,joblib=joblib.__version__),hardware=dict(os=platform.system(),machine=platform.machine(),processor=platform.processor(),CUDA='not used; CPU only'),elapsed_seconds=time.perf_counter()-started)
    dump(out/'training_log.json',log);dump(out/'group_split.json',audit);dump(out/'oof_check.json',oof)
    return parameter,log

def nested_rebuilt(key,data,outdir):
    """Reproduce the final rebuilt engine's full nested model/feature selection.
    This intentionally takes longer; the package weights are never overwritten.
    """
    import shutil
    cfg=json.loads((ROOT/'models/training-configs.json').read_text(encoding='utf8'))[key]
    if cfg['engine']!='rebuilt':raise ValueError('Nested-selection option is for the four rebuilt engines; other final-fit cores and archived selection logs are included.')
    runroot=Path(outdir)/('nested_'+key);(runroot/'data').mkdir(parents=True,exist_ok=True)
    shutil.copyfile(data,runroot/'data'/(cfg['native']+'.csv'))
    modeling.ROOT=runroot;data_io.ROOT=runroot
    return modeling.train_model(cfg['native'])
