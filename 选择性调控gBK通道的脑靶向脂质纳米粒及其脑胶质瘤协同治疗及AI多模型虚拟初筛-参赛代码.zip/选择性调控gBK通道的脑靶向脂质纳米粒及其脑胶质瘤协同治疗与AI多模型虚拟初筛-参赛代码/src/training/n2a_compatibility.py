"""Final N2a compatibility estimator primitives, copied verbatim from its final training implementation.
The packaging wrapper only selects the existing compatibility/weighted task.
"""
import math
from collections import Counter,defaultdict
import numpy as np
from scipy.stats import spearmanr
from sklearn.feature_extraction import DictVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge,LogisticRegression
from sklearn.ensemble import ExtraTreesRegressor,RandomForestRegressor
def split(rows,k=5,seed=42):
 # BBB balances papers; every occurrence of a formulation remains in one fold.
 rng=np.random.default_rng(seed);by=defaultdict(set)
 for r in rows:by[r['doi'] if r['family']=='bbb' else 'all'].add(r['split_group'])
 folds=[set() for _ in range(k)]
 for _,groups in sorted(by.items()):
  gs=sorted(groups);rng.shuffle(gs)
  for j,g in enumerate(gs):folds[j%k].add(g)
 for held in folds:
  tr=[r for r in rows if r['split_group'] not in held];va=[r for r in rows if r['split_group'] in held]
  if tr and va:
   assert not {r['split_group'] for r in tr}&{r['split_group'] for r in va}
   yield tr,va

def features(family,enriched):
 if family=='bbb':return ['particle_size','pdi','zeta_potential','encapsulation_efficiency','time_h'],['context']+(['surface_identity'] if enriched else [])
 return ['particle_size','apparent_pka'],(['headgroup_precursor'] if enriched else [])

def dictionaries(rows,num,cat):
 out=[]
 for r in rows:
  if any(r.get(f,'')=='' for f in num+cat):raise ValueError('Missing required feature; no imputation')
  d={f:float(r[f]) for f in num}
  if not all(math.isfinite(v) for v in d.values()):raise ValueError('Nonfinite feature')
  d.update({f:str(r[f]) for f in cat});out.append(d)
 return out

def weights(rows,weighted):
 if not weighted:return np.ones(len(rows))
 counts=Counter(r['split_group'] for r in rows)
 if rows[0]['family']=='bbb':
  # All current full-profile rows are estimates: source factor cancels here.
  w=np.array([(1 if r['target_source_type']=='原文实测值' else .5)/counts[r['split_group']] for r in rows])
 else:
  v=np.array([(float(r['replicate_sd'])/math.sqrt(float(r['n_values'])))**2 for r in rows])
  if rows[0]['family']=='functional_delivery':v/=np.square(1+np.array([float(r['target']) for r in rows]))
  positive=v[v>0];floor=float(np.median(positive)) if len(positive) else 1.
  w=1/np.maximum(v,floor);w=np.clip(w/w.mean(),.2,5)
 return w/w.mean()

class ScreeningModel:
 def __init__(self,config,family):self.config=config;self.family=family
 def fit(self,rows):
  self.num,self.cat=features(self.family,self.config['variant']!='baseline')
  self.vectorizer=DictVectorizer(sparse=False);x=self.vectorizer.fit_transform(dictionaries(rows,self.num,self.cat))
  self.scaler=StandardScaler();x=self.scaler.fit_transform(x);y=np.array([float(r['target']) for r in rows]);w=weights(rows,self.config['variant']=='weighted')
  self.ranges={f:[min(float(r[f]) for r in rows),max(float(r[f]) for r in rows)] for f in self.num};self.categories={f:sorted({r[f] for r in rows}) for f in self.cat}
  self.protocols=sorted({r['rank_stratum'] for r in rows});self.groups=sorted({r['split_group'] for r in rows})
  algo=self.config['algorithm'];self.is_rank=algo=='pairwise'
  if self.is_rank:
   dx=[];labels=[];pw=[]
   for i in range(len(rows)):
    for j in range(i):
     if rows[i]['split_group']==rows[j]['split_group'] or rows[i]['rank_stratum']!=rows[j]['rank_stratum'] or y[i]==y[j]:continue
     dx.extend([x[i]-x[j],x[j]-x[i]]);labels.extend([int(y[i]>y[j]),int(y[j]>y[i])]);pw.extend([math.sqrt(w[i]*w[j])]*2)
   if not dx:raise ValueError('No comparable training pairs')
   self.model=LogisticRegression(C=self.config['parameter'],fit_intercept=False,max_iter=2000,solver='lbfgs')
   self.model.fit(np.asarray(dx),labels,sample_weight=np.asarray(pw)/np.mean(pw));self.training_pair_count=len(dx)//2
  else:
   if self.family=='functional_delivery':y=np.log1p(y)
   if self.family=='bbb':y=np.log(np.clip(y/100,1e-8,1-1e-8)/(1-np.clip(y/100,1e-8,1-1e-8)))
   if algo=='ridge':self.model=Ridge(alpha=self.config['parameter'])
   else:
    cls=ExtraTreesRegressor if algo=='extra_trees' else RandomForestRegressor
    self.model=cls(n_estimators=96,max_depth=5,min_samples_leaf=int(self.config['parameter']),random_state=20260927,n_jobs=1)
   self.model.fit(x,y,sample_weight=w)
  return self
 def predict(self,rows):
  x=self.scaler.transform(self.vectorizer.transform(dictionaries(rows,self.num,self.cat)))
  if self.is_rank:return x@self.model.coef_[0]
  p=self.model.predict(x)
  if self.family=='functional_delivery':return np.expm1(p)
  if self.family=='bbb':return 100/(1+np.exp(-np.clip(p,-700,700)))
  return p

def metrics(rows,p,ranking=False):
 y=np.array([float(r['target']) for r in rows]);p=np.asarray(p);rho=[];rec=[];con=[]
 for s in sorted({r['rank_stratum'] for r in rows}):
  ids=[i for i,r in enumerate(rows) if r['rank_stratum']==s];a=y[ids];b=p[ids]
  if len(ids)<3 or np.ptp(a)<1e-12:continue
  rho.append(float(spearmanr(a,b).statistic) if np.ptp(b)>1e-12 else 0.)
  k=max(1,math.ceil(.2*len(ids)));rec.append(len(set(np.argsort(a)[-k:])&set(np.argsort(b)[-k:]))/k)
  pairs=[np.sign((a[i]-a[j])*(b[i]-b[j])) for i in range(len(ids)) for j in range(i) if a[i]!=a[j]]
  if pairs:con.append(float(np.mean([(v+1)/2 for v in pairs])))
 den=np.sum((y-y.mean())**2)
 return dict(n=len(rows),groups=len({r['split_group'] for r in rows}),Spearman=float(np.mean(rho)) if rho else 0.,top20_recall=float(np.mean(rec)) if rec else '',pairwise_concordance=float(np.mean(con)) if con else '',R2='' if ranking or den==0 else float(1-np.sum((y-p)**2)/den),MAE='' if ranking else float(np.mean(abs(y-p))))

def configs(variant):
 if variant=='rank':return [dict(variant='rank',algorithm='pairwise',parameter=c) for c in [.01,.1,1.]]
 return [dict(variant=variant,algorithm=a,parameter=p) for a,ps in [('ridge',[1.,10.,100.]),('extra_trees',[3,8]),('random_forest',[3,8])] for p in ps]

def select(rows,variant):
 candidates=[]
 for cfg in configs(variant):
  scores=[]
  for tr,va in split(rows,3,2026):
   m=ScreeningModel(cfg,rows[0]['family']).fit(tr);scores.append(metrics(va,m.predict(va),m.is_rank)['Spearman'])
  candidates.append((np.mean(scores),cfg))
 return max(candidates,key=lambda z:z[0])[1]
