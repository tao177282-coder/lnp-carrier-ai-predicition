# 归属：M1–M5共用训练引擎；每次调用仅加载一个模型CSV。
"""Nested formulation-grouped model/feature selection with honest OOF evaluation."""
import json,math,argparse
from collections import defaultdict
import numpy as np
import joblib,sklearn
from sklearn.feature_extraction import DictVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor,ExtraTreesRegressor,GradientBoostingRegressor
from scipy.stats import spearmanr
from specifications import ROOT,SPECS,DESCRIPTIONS
from data_io import load_data,write_csv,grouped_folds,group_means,training_weights

class FittedModel:
 """Serializable pipeline; encoder/scaler/weights are fit only on training rows."""
 def __init__(self,model_id,config):self.model_id=model_id;self.config=config
 def records(self,rows):
  return [{**{f:float(r[f]) for f in self.numeric},**{f:r[f] for f in self.categorical}} for r in rows]
 def fit(self,rows):
  spec=SPECS[self.model_id];self.numeric,self.categorical=spec['sets'][self.config['features']]
  self.vectorizer=DictVectorizer(sparse=False);x=self.vectorizer.fit_transform(self.records(rows));self.scaler=StandardScaler();x=self.scaler.fit_transform(x)
  y=np.array([float(r['target']) for r in rows]);y=np.log1p(y) if spec['transform']=='log1p' else y
  w=training_weights(rows,self.config['reliability'],spec['transform']);a=self.config['algorithm'];p=self.config['parameter']
  if a=='ridge':self.estimator=Ridge(alpha=p)
  elif a=='gradient_boosting':self.estimator=GradientBoostingRegressor(n_estimators=100,learning_rate=.04,max_depth=int(p),min_samples_leaf=5,loss='huber',random_state=20260928)
  else:
   cls=ExtraTreesRegressor if a=='extra_trees' else RandomForestRegressor
   self.estimator=cls(n_estimators=96,max_depth=5,min_samples_leaf=int(p),max_features=1.,random_state=20260928,n_jobs=1)
  self.estimator.fit(x,y,sample_weight=w)
  self.categories={f:sorted({r[f] for r in rows}) for f in self.categorical};self.ranges={f:[min(float(r[f]) for r in rows),max(float(r[f]) for r in rows)] for f in self.numeric}
  return self
 def predict(self,rows):
  x=self.scaler.transform(self.vectorizer.transform(self.records(rows)));p=self.estimator.predict(x)
  return np.expm1(p) if SPECS[self.model_id]['transform']=='log1p' else p

def metrics(rows,p):
 _,pairs=group_means(rows,p);y,p=pairs.T;den=np.sum((y-y.mean())**2);k=max(1,math.ceil(.2*len(y)))
 rho=float(spearmanr(y,p).statistic) if np.ptp(y)>1e-12 and np.ptp(p)>1e-12 and len(y)>=3 else 0.
 # Fractional inclusion at the top-k boundary avoids arbitrary tie-breaking.
 def top_weights(v):
  cut=np.sort(v)[-k];above=v>cut;tied=v==cut;return above.astype(float)+tied*(k-above.sum())/tied.sum()
 return dict(groups=len(y),R2=float(1-np.sum((y-p)**2)/den) if den>0 else None,Spearman=rho,MAE=float(np.mean(abs(y-p))),RMSE=float(np.sqrt(np.mean((y-p)**2))),top20_recall=float(np.dot(top_weights(y),top_weights(p))/k))
def configurations(model_id):
 for fs in SPECS[model_id]['sets']:
  for weighted in ([False] if model_id=='M4_size' else [False,True]):
   for algo,params in [('ridge',[1.,10.,100.]),('extra_trees',[3,8]),('random_forest',[3,8]),('gradient_boosting',[1,2])]:
    for value in params:yield dict(algorithm=algo,parameter=value,features=fs,reliability=weighted)
def select(rows,model_id):
 objective=SPECS[model_id]['objective'];scores=[]
 for cfg in configurations(model_id):
  mm=[]
  for tr,va in grouped_folds(rows,3,2026):
   model=FittedModel(model_id,cfg).fit(tr);mm.append(metrics(va,model.predict(va)))
  scores.append(dict(config=cfg,selection_score=float(np.mean([m[objective] if m[objective] is not None else -1e9 for m in mm])),MAE=float(np.mean([m['MAE'] for m in mm]))))
 def best(rr):return max(rr,key=lambda r:(r['selection_score'],-r['MAE']))['config']
 return {a:best([r for r in scores if r['config']['algorithm']==a]) for a in ['ridge','extra_trees','random_forest','gradient_boosting']},best(scores),scores
def train_model(model_id):
 rows=load_data(model_id);out=ROOT/'results'/model_id;out.mkdir(parents=True,exist_ok=True);predictions=[];choices=[];importance=[];foldmetrics=[];rng=np.random.default_rng(301)
 for fold,(tr,va) in enumerate(grouped_folds(rows),1):
  algorithms,best,tuning=select(tr,model_id);algorithms['selected']=best
  for name,cfg in algorithms.items():
   model=FittedModel(model_id,cfg).fit(tr);p=model.predict(va);met=metrics(va,p);foldmetrics.append(dict(fold=fold,algorithm=name,**met))
   choices.append(dict(fold=fold,algorithm=name,config=json.dumps(cfg),training_groups=';'.join(sorted({r['split_group'] for r in tr})),validation_groups=';'.join(sorted({r['split_group'] for r in va}))))
   for r,pr in zip(va,p):predictions.append(dict(sample_id=r['sample_id'],split_group=r['split_group'],doi=r['doi'],source_type=r['target_source_type'],fold=fold,algorithm=name,target=float(r['target']),prediction=float(pr),unseen_category=int(any(r[f] not in model.categories[f] for f in model.categorical))))
   if name=='selected':
    for feature in model.numeric+model.categorical:
     # Permute at recipe level, preserving repeated central-point inputs.
     ids=sorted({r['split_group'] for r in va});vals={g:next(r[feature] for r in va if r['split_group']==g) for g in ids}
     for repeat in range(5):
      shuffled=dict(zip(ids,rng.permutation([vals[g] for g in ids])));vv=[dict(r,**{feature:shuffled[r['split_group']]}) for r in va];mm=metrics(va,model.predict(vv))
      importance.append(dict(fold=fold,feature=feature,repeat=repeat,delta_MAE=mm['MAE']-met['MAE'],delta_Spearman=met['Spearman']-mm['Spearman']))
  baseline=np.average([float(r['target']) for r in tr],weights=training_weights(tr,False,'identity'))
  for r in va:predictions.append(dict(sample_id=r['sample_id'],split_group=r['split_group'],doi=r['doi'],source_type=r['target_source_type'],fold=fold,algorithm='training_mean',target=float(r['target']),prediction=float(baseline),unseen_category=0))
  print(model_id,'outer fold',fold,'selected',best,flush=True)
 comparison=[]
 for a in ['ridge','extra_trees','random_forest','gradient_boosting','selected','training_mean']:
  rr=[r for r in predictions if r['algorithm']==a];comparison.append(dict(algorithm=a,scope='pooled OOF after recipe averaging',**metrics(rr,[r['prediction'] for r in rr]),unseen_category_rows=sum(r['unseen_category'] for r in rr)))
 _,cfg,_=select(rows,model_id);final=FittedModel(model_id,cfg).fit(rows);joblib.dump(final,out/'model.joblib')
 selected=next(r for r in comparison if r['algorithm']=='selected');baseline=next(r for r in comparison if r['algorithm']=='training_mean')
 meta=dict(model_id=model_id,name=SPECS[model_id]['name'],endpoint=SPECS[model_id]['endpoint'],unit=SPECS[model_id]['unit'],protocol=SPECS[model_id]['protocol'],config=cfg,n_rows=len(rows),n_formulations=len({r['split_group'] for r in rows}),measured_rows=sum(r['target_source_type']=='原文实测值' for r in rows),estimated_rows=sum('估读' in r['target_source_type'] for r in rows),sources=sorted({r['doi'] for r in rows}),numeric=final.numeric,categorical=final.categorical,ranges=final.ranges,categories=final.categories,cv=selected,baseline=baseline,versions=dict(sklearn=sklearn.__version__,numpy=np.__version__),external_validation=False)
 (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8');(out/'input_example.json').write_text(json.dumps({f:rows[0][f] for f in final.numeric+final.categorical},ensure_ascii=False,indent=2),encoding='utf8')
 write_csv(out/'comparison.csv',comparison);write_csv(out/'oof_predictions.csv',predictions);write_csv(out/'fold_metrics.csv',foldmetrics);write_csv(out/'selection_audit.csv',choices);write_csv(out/'importance.csv',importance)
 return meta
if __name__=='__main__':
 import sys
 sys.modules['modeling']=sys.modules[__name__];FittedModel.__module__='modeling'
 p=argparse.ArgumentParser();p.add_argument('--model',choices=list(SPECS)+['all'],default='all');args=p.parse_args()
 for key in SPECS if args.model=='all' else [args.model]:train_model(key)
