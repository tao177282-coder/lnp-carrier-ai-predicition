# 归属：M1–M5共用；读取、缺失检查、分组及独立配方统计。
"""No imputation, outcome winsorization or error-driven sample deletion."""
import csv,math
from collections import defaultdict,Counter
from pathlib import Path
import numpy as np
from specifications import ROOT,SPECS
def read_csv(path):
 with open(path,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write_csv(path,rows):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 if not rows:return
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,list(dict.fromkeys(k for r in rows for k in r)));w.writeheader();w.writerows(rows)
def finite(value):
 try:return math.isfinite(float(value))
 except (TypeError,ValueError):return False
def load_data(model_id):
 spec=SPECS[model_id];rows=read_csv(ROOT/'data'/f'{model_id}.csv')
 allnum={f for nums,cats in spec['sets'].values() for f in nums};allcat={f for nums,cats in spec['sets'].values() for f in cats}
 for r in rows:
  if r['model_id']!=model_id or r['target_unit']!=spec['unit']:raise ValueError('Mixed endpoint or unit')
  if not r['doi'] or not r['split_group'] or not r['target_source_locators']:raise ValueError('Missing provenance/group')
  if not finite(r['target']) or any(not finite(r.get(f)) for f in allnum):raise ValueError('Missing/nonfinite input; inspect source, do not impute')
  if any(r.get(f,'')=='' for f in allcat):raise ValueError('Missing category')
  y=float(r['target'])
  if y<0 or model_id=='M4_size' and y<=0 or model_id=='M5_encapsulation' and y>100:raise ValueError('Physically invalid target; source verification required')
  # MTT viability can exceed100 after normalization. Do not clip it to100.
 assert len({r['sample_id'] for r in rows})==len(rows)
 return rows
def grouped_folds(rows,k=5,seed=42,key='split_group'):
 groups=sorted({r[key] for r in rows});np.random.default_rng(seed).shuffle(groups)
 for gs in np.array_split(groups,min(k,len(groups))):
  held=set(gs);tr=[r for r in rows if r[key] not in held];va=[r for r in rows if r[key] in held]
  if tr and va:
   assert not {r['split_group'] for r in tr}&{r['split_group'] for r in va}
   yield tr,va
def group_means(rows,predictions):
 """Evaluation counts a repeated recipe once. Raw records remain in the CSV."""
 grouped=defaultdict(list)
 for r,p in zip(rows,predictions):grouped[r['split_group']].append((float(r['target']),float(p)))
 return sorted(grouped),np.array([np.mean(grouped[g],axis=0) for g in sorted(grouped)])
def training_weights(rows,reliability,transform):
 counts=Counter(r['split_group'] for r in rows);w=np.array([1/counts[r['split_group']] for r in rows],float)
 if reliability and all(finite(r.get('replicate_sd')) and finite(r.get('n_values')) and float(r['n_values'])>1 for r in rows):
  variance=np.array([float(r['replicate_sd'])**2/float(r['n_values']) for r in rows])
  if transform=='log1p':variance/=np.square(1+np.array([float(r['target']) for r in rows]))
  positive=variance[variance>0];floor=np.median(positive) if len(positive) else 1.
  precision=1/np.maximum(variance,floor);w*=np.clip(precision/precision.mean(),.2,5)
 return w/w.mean()
