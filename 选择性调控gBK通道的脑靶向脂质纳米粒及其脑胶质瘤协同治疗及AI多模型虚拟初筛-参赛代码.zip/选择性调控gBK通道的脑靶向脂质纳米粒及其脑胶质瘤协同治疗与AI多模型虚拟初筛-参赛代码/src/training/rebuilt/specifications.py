# 归属：M1–M5共用；各模型独立的输入/输出定义，不混合实验数据。
"""Explicit feature allowlists. Metadata, source IDs and outcomes are never inputs."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
HEADGROUPS=['D-serine','L-DOPA','MK-0752','cinnamic acid','temozolomide','tryptamine']
BIO_SETS={
 'compact':(['particle_size','apparent_pka'],['headgroup_precursor']),
 'expanded':(['particle_size','apparent_pka','zeta_potential','encapsulation_efficiency'],['headgroup_precursor']),
}
SPECS={
 'M1_delivery_N2a':dict(name='N2a功能性mRNA递送',unit='fold',endpoint='相对MC3对照的荧光素酶表达倍数',objective='Spearman',transform='log1p',sets=BIO_SETS,protocol='N2a; FLuc mRNA; 50 ng/well; 18 h; Bright-Glo; MC3 reference'),
 'M2_delivery_bEnd3':dict(name='bEnd.3功能性mRNA递送',unit='fold',endpoint='相对MC3对照的荧光素酶表达倍数',objective='Spearman',transform='log1p',sets=BIO_SETS,protocol='bEnd.3; FLuc mRNA; 50 ng/well; 18 h; Bright-Glo; MC3 reference'),
 'M3_viability_bEnd3':dict(name='bEnd.3细胞相容性',unit='%',endpoint='相对PBS对照的MTT细胞活力',objective='Spearman',transform='identity',sets=BIO_SETS,protocol='bEnd.3; 24 h; MTT; PBS reference; dose not verified'),
 'M4_size':dict(name='siRNA-LNP粒径',unit='nm',endpoint='DLS Z-average粒径',objective='R2',transform='log1p',sets={'six_design_inputs':(['np_ratio','cationic_pct','nt_ratio_pct','chol_phos_ratio','peg_pct'],['helper'])},protocol='Tong ACS Chem Biol SI Table S1; SM-102/NT1-O14B; DMG-PEG; microfluidic aqueous:ethanol:PBS=5:1:5; siRNA-loaded protocol'),
}
DESCRIPTIONS={
 'particle_size':('LNP水动力学粒径','nm'),
 'apparent_pka':('原文TNS曲线标注的表观pKa','dimensionless'),
 'zeta_potential':('Zeta电位','mV'),
 'encapsulation_efficiency':('核酸包封率','%'),
 'headgroup_precursor':('脂质头基前体类别；不代表完整结构','category'),
 'np_ratio':('脂质氮与核酸磷的N/P比','ratio'),
 'cationic_pct':('两种阳离子脂质合计占总脂质的摩尔百分比','mol%'),
 'nt_ratio_pct':('NT1-O14B占阳离子脂质部分的百分比','% of cationic lipids'),
 'chol_phos_ratio':('胆固醇与磷脂的摩尔比','ratio'),
 'peg_pct':('DMG-PEG占总脂质摩尔百分比','mol%'),
 'helper':('辅助磷脂种类','category'),
}
