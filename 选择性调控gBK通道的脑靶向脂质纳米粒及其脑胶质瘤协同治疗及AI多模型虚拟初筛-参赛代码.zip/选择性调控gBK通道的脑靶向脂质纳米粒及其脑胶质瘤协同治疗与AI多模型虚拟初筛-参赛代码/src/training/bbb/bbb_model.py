"""Conditional in-vitro BBB transport screening. Requires NumPy only.

All assays remain separate categorical contexts with shared regularized effects.
No prediction of in-vivo brain exposure, RNA mass transport, or a new BBB assay.
"""
import json,argparse,math
from pathlib import Path
import numpy as np
from numpy_models import Regressor,score,svg_importance
from prepare_bbb import ROOT,read,write
FEATURES={'full':['particle_size','pdi','zeta_potential','encapsulation_efficiency','time_h'],'minimal':['particle_size','time_h']}
CONFIGS=[('ridge',1.),('ridge',10.),('ridge',100.),('gpr',1.),('gpr',3.)]
def transform(y):
 p=np.asarray(y,dtype=float)/100;return np.log(p/(1-p))
def inverse(y):return 100/(1+np.exp(-np.clip(y,-700,700)))
def split(rows,k=3,seed=42):
 # Balance papers while preserving ALL observations of a formulation in one fold.
 rng=np.random.default_rng(seed);by={}
 for r in rows:by.setdefault(r['doi'],set()).add(r['split_group'])
 parts=[set() for _ in range(k)]
 for doi,gs in sorted(by.items()):
  gs=sorted(gs);rng.shuffle(gs)
  for j,g in enumerate(gs):parts[j%k].add(g)
 for hold in parts:
  tr=[r for r in rows if r['split_group'] not in hold];va=[r for r in rows if r['split_group'] in hold]
  if tr and va:yield tr,va
def fitted(rows,features,method,param):
 return Regressor(method,param,features,['context'],False).fit([dict(r,target=float(transform([r['target_percent']])[0])) for r in rows])
def predict_rows(model,rows):return inverse(model.predict(rows))
def choose(rows,features):
 scores=[]
 for method,param in CONFIGS:
  errors=[]
  for tr,va in split(rows,3,13):
   m=fitted(tr,features,method,param);p=m.predict(va);y=transform([r['target_percent'] for r in va])
   # Equal aggregate weight per formulation, not per point in a four-time curve.
   for g in {r['split_group'] for r in va}:
    idx=[i for i,r in enumerate(va) if r['split_group']==g];errors.append(float(np.mean((p[idx]-y[idx])**2)))
  scores.append((np.mean(errors),method,param))
 return min(scores)[1:]
def metrics(oof):
 y=[r['actual'] for r in oof];p=[r['predicted'] for r in oof];m=score(y,p)
 m['baseline_MAE']=float(np.mean([abs(r['actual']-r['baseline']) for r in oof]));m['unique_formulations']=len({r['split_group'] for r in oof})
 m['group_balanced_MAE']=float(np.mean([np.mean([abs(r['actual']-r['predicted']) for r in oof if r['split_group']==g]) for g in {r['split_group'] for r in oof}]))
 den=sum((r['actual']-r['baseline'])**2 for r in oof);m['skill_vs_context_baseline']=None if den==0 else 1-sum((r['actual']-r['predicted'])**2 for r in oof)/den
 return m
def train():
 data=read(ROOT/'data/bbb_modeling.csv');out=ROOT/'results';out.mkdir(exist_ok=True);registry=[];summary=[]
 for variant,features in FEATURES.items():
  rows=[r for r in data if r[variant+'_eligible']=='1'];oof=[];imps={f:[] for f in features};rng=np.random.default_rng(23)
  for fold,(tr,va) in enumerate(split(rows),1):
   assert not {r['split_group'] for r in tr}&{r['split_group'] for r in va}
   method,param=choose(tr,features);model=fitted(tr,features,method,param);p=predict_rows(model,va)
   for r,v in zip(va,p):
    # Same context AND time baseline where available; otherwise same context median.
    a=[float(x['target_percent']) for x in tr if x['context']==r['context'] and x['time_h']==r['time_h']]
    if not a:a=[float(x['target_percent']) for x in tr if x['context']==r['context']]
    assert a,'Unseen assay in test fold'
    oof.append(dict(sample_id=r['sample_id'],split_group=r['split_group'],doi=r['doi'],context=r['context'],time_h=r['time_h'],actual=float(r['target_percent']),predicted=float(v),baseline=float(np.median(a)),source_type=r['source_type'],small_sample=r['is_small_sample_extension'],fold=fold,method=method,param=param))
   base=np.mean(np.abs(np.array([float(r['target_percent']) for r in va])-p))
   for feature in features:
    for rep in range(3):
     a=[dict(r) for r in va]
     for ctx in {r['context'] for r in va}:
      ids=[i for i,r in enumerate(va) if r['context']==ctx];values=[va[i][feature] for i in ids];rng.shuffle(values)
      for i,v in zip(ids,values):a[i][feature]=v
     imps[feature].append(float(np.mean(np.abs(np.array([float(r['target_percent']) for r in va])-predict_rows(model,a)))-base))
  write(out/(variant+'_out_of_fold.csv'),oof)
  for ctx in ['all']+sorted({r['context'] for r in oof}):
   part=oof if ctx=='all' else [r for r in oof if r['context']==ctx];summary.append(dict(variant=variant,context=ctx,**metrics(part)))
  method,param=choose(rows,features);model=fitted(rows,features,method,param);model.save(out/(variant+'.json'))
  contexts={}
  for ctx in sorted({r['context'] for r in rows}):
   sub=[r for r in rows if r['context']==ctx]
   contexts[ctx]=dict(tracer=sub[0]['tracer_definition'],model=sub[0]['cell_or_animal_model'],bbb_model=sub[0]['bbb_model_description'],dose_values=sorted({r['dose_value'] for r in sub}),dose_units=sorted({r['dose_unit'] for r in sub}),feature_ranges={f:[min(float(r[f]) for r in sub),max(float(r[f]) for r in sub)] for f in features},formulations=len({r['split_group'] for r in sub}))
  registry.append(dict(variant=variant,features=features,contexts=contexts,method=method,param=param,rows=len(rows),unique_formulations=len({r['split_group'] for r in rows}),metrics=metrics(oof),note='Shared conditional model; not universal BBB efficiency; estimated values dominate'))
  importance={k:float(np.mean(v)) for k,v in imps.items()};svg_importance(out/(variant+'_importance.svg'),importance)
  write(out/(variant+'_importance.csv'),[dict(feature=k,heldout_delta_MAE=v) for k,v in importance.items()])
  example={f:float(rows[0][f]) for f in features};example['context']=rows[0]['context'];(ROOT/(variant+'_example.json')).write_text(json.dumps(example,ensure_ascii=False,indent=2),encoding='utf8')
 write(out/'evaluation.csv',summary);(out/'registry.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps([dict(variant=r['variant'],rows=r['rows'],groups=r['unique_formulations'],metrics=r['metrics']) for r in registry],ensure_ascii=False,indent=2))
def predict_bbb(inputs,variant='full',allow_extrapolation=False):
 """Input size nm, zeta mV, PDI, encapsulation %, time h and an exact assay context.
 minimal variant needs only size/time/context. It is less chemically informative.
 """
 registry=json.loads((ROOT/'results/registry.json').read_text(encoding='utf8'));r=next((r for r in registry if r['variant']==variant),None)
 if not r:raise ValueError('variant must be full or minimal')
 ctx=inputs.get('context');meta=r['contexts'].get(ctx)
 if meta is None:raise ValueError('Unvalidated assay context; select from results/registry.json')
 warnings=[]
 for f in r['features']:
  if inputs.get(f) in [None,'']:raise ValueError('Missing '+f+'; no imputation')
  v=float(inputs[f])
  if not math.isfinite(v):raise ValueError('Nonfinite '+f)
  low,high=meta['feature_ranges'][f]
  if not low<=v<=high:warnings.append(f+' outside THIS assay training range')
 if warnings and not allow_extrapolation:raise ValueError('; '.join(warnings))
 m=Regressor.load(ROOT/'results'/f'{variant}.json');p,lo,hi=m.predict([inputs],True);value=float(inverse(p)[0])
 return dict(predicted_transport_percent=value,context=ctx,tracer_definition=meta['tracer'],variant=variant,validation_status='exploratory_only_not_validated_for_formulation_ranking',model_interval_95=None if lo is None else [float(inverse(lo)[0]),float(inverse(hi)[0])],warnings=warnings+['In-vitro assay-specific proxy; not in-vivo BBB or glioma efficacy.','Both versions failed to beat the pooled context/time baseline; pooled R2 reflects differences between assays.','Small dataset dominated by graph estimates; no validated extrapolation to new glycosylated chemistry.','Any GP interval is conditional and uncalibrated; no fabricated interval for ridge.'],cv_metrics=r['metrics'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--train',action='store_true');p.add_argument('--predict-json');p.add_argument('--variant',default='full');a=p.parse_args()
 if a.train:train()
 elif a.predict_json:print(json.dumps(predict_bbb(json.loads(Path(a.predict_json).read_text(encoding='utf8')),a.variant),ensure_ascii=False,indent=2))
 else:p.print_help()
