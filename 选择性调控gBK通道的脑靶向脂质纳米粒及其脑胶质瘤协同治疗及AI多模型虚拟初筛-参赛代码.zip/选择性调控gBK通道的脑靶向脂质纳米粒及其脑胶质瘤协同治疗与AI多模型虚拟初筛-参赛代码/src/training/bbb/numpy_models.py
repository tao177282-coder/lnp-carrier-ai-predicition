"""Shared NumPy regression primitives; standard ridge and Matern-3/2 GPR."""

import csv,json,math,hashlib,argparse

from pathlib import Path

import numpy as np

class Encoder:
 def __init__(self,numeric,categorical):self.numeric=numeric;self.categorical=categorical
 def fit(self,rows):
  a=np.array([[float(r[k]) for k in self.numeric] for r in rows]);self.mean=a.mean(0);self.sd=a.std(0);self.sd[self.sd<1e-12]=1
  self.levels={k:sorted({r[k] for r in rows}) for k in self.categorical};self.low=a.min(0);self.high=a.max(0)
  return self
 def transform(self,rows):
  a=(np.array([[float(r[k]) for k in self.numeric] for r in rows])-self.mean)/self.sd
  blocks=[a]
  for k,levels in self.levels.items():blocks.append(np.array([[float(r[k]==v) for v in levels] for r in rows]))
  return np.column_stack(blocks)

def kernel(a,b,length):
 dist=np.maximum((a*a).sum(1)[:,None]+(b*b).sum(1)[None,:]-2*a@b.T,0)
 z=np.sqrt(3*dist/max(a.shape[1],1))/length
 return (1+z)*np.exp(-z)

class Regressor:
 def __init__(self,method,param,numeric,categorical,log_target=False):
  self.method=method;self.param=param;self.encoder=Encoder(numeric,categorical);self.log_target=log_target
 def fit(self,rows):
  self.x=self.encoder.fit(rows).transform(rows)
  y=np.array([float(r['target']) for r in rows]);y=np.log10(y) if self.log_target else y
  self.ymean=float(y.mean());self.ysd=max(float(y.std()),1e-8);z=(y-self.ymean)/self.ysd
  # Both regularizers act on standardized variables. Fixed GP noise variance=0.05.
  if self.method=='ridge':
   a=np.column_stack([np.ones(len(z)),self.x]);penalty=np.eye(a.shape[1])*self.param;penalty[0,0]=1e-8
   self.coef=np.linalg.solve(a.T@a+penalty,a.T@z)
  else:
   self.noise=.05;self.chol=np.linalg.cholesky(kernel(self.x,self.x,self.param)+np.eye(len(z))*(self.noise+1e-8))
   self.alpha=np.linalg.solve(self.chol.T,np.linalg.solve(self.chol,z))
  return self
 def predict(self,rows,interval=False):
  a=self.encoder.transform(rows)
  if self.method=='ridge':m=np.column_stack([np.ones(len(a)),a])@self.coef;s=None
  else:
   k=kernel(a,self.x,self.param);m=k@self.alpha
   v=np.linalg.solve(self.chol,k.T);s=np.sqrt(np.maximum(1+self.noise-(v*v).sum(0),1e-10))*self.ysd
  m=m*self.ysd+self.ymean
  pred=10**m if self.log_target else m
  if not interval:return pred
  if s is None:return pred,None,None
  return pred,(10**(m-1.96*s) if self.log_target else m-1.96*s),(10**(m+1.96*s) if self.log_target else m+1.96*s)
 def save(self,path):
  d=dict(method=self.method,param=self.param,numeric=self.encoder.numeric,categorical=self.encoder.categorical,levels=self.encoder.levels,mean=self.encoder.mean.tolist(),sd=self.encoder.sd.tolist(),low=self.encoder.low.tolist(),high=self.encoder.high.tolist(),log_target=self.log_target,ymean=self.ymean,ysd=self.ysd)
  if self.method=='ridge':d['coef']=self.coef.tolist()
  else:d.update(x=self.x.tolist(),chol=self.chol.tolist(),alpha=self.alpha.tolist(),noise=self.noise)
  Path(path).write_text(json.dumps(d,ensure_ascii=False),encoding='utf8')
 @classmethod
 def load(cls,path):
  d=json.loads(Path(path).read_text(encoding='utf8'));m=cls(d['method'],d['param'],d['numeric'],d['categorical'],d['log_target'])
  for k in ['ymean','ysd','noise']:
   if k in d:setattr(m,k,d[k])
  for k in ['coef','x','chol','alpha']:
   if k in d:setattr(m,k,np.array(d[k]))
  for k in ['mean','sd','low','high']:setattr(m.encoder,k,np.array(d[k]))
  m.encoder.levels=d['levels'];return m

def score(y,p):
 y=np.asarray(y);p=np.asarray(p);den=float(((y-y.mean())**2).sum())
 def ranks(a):
  s=np.argsort(a);z=np.empty(len(a));i=0
  while i<len(a):
   j=i+1
   while j<len(a) and a[s[j]]==a[s[i]]:j+=1
   z[s[i:j]]=(i+j-1)/2;i=j
  return z
 ry,rp=ranks(y),ranks(p);rho=float(np.corrcoef(ry,rp)[0,1]) if ry.std()>0 and rp.std()>0 else None
 return dict(n=len(y),MAE=float(np.abs(y-p).mean()),RMSE=float(np.sqrt(((y-p)**2).mean())),R2=None if den<1e-12 else 1-float(((y-p)**2).sum())/den,Spearman=rho)

def svg_importance(path,values):
 import html
 vals=sorted(values.items(),key=lambda t:t[1],reverse=True);height=80+len(vals)*35;scale=max([abs(v) for _,v in vals]+[1e-9])
 out=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="{height}"><rect width="100%" height="100%" fill="white"/><text x="20" y="28" font-family="Arial" font-size="17">Held-out permutation importance (increase in MAE; negative = no reliable contribution)</text>']
 for i,(name,v) in enumerate(vals):
  y=65+i*35;out.append(f'<text x="20" y="{y}" font-family="Arial" font-size="14">{html.escape(name)}</text><rect x="330" y="{y-16}" width="{max(0,v)/scale*470:.1f}" height="22" fill="#377d9a"/><text x="830" y="{y}" font-family="Arial" font-size="14">{v:.4g}</text>')
 Path(path).write_text(''.join(out)+'</svg>',encoding='utf8')
