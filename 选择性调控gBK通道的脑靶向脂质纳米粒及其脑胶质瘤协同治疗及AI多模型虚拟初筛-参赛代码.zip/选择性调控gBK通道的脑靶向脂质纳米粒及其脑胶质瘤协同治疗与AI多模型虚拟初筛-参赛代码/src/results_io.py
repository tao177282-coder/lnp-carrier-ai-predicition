"""Submission CSV formatting; missing model output is never filled with zero."""
import csv,json
from pathlib import Path
from src.inference import predict_batch,catalog

ROOT=Path(__file__).resolve().parents[1]
RUN_VERSION='competition-20261001-final6-mc3'
HEADERS=['候选编号','所属赛道','组分信息','项目目标','模型名称','实验终点','预测值','单位','模型版本','运行版本','结果状态','比较组','实验条件','输入参数','参考文献DOI','既知真值筛选','外部验证','备注']

def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
def write_csv(path,rows,headers=HEADERS):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=headers);writer.writeheader();writer.writerows(rows)

def run(payload,provenance=None):
    """The wrapper adds submission metadata; scientific inference stays unchanged."""
    sources={r['name']:r for r in provenance or []}
    known={r['name']:r['inputs'] for r in read_json(ROOT/'data/examples/four_candidates.json')['formulations']}
    records=predict_batch(payload)
    for row in records:
        source=sources.get(row['name'],{})
        # A known example is explicitly a replay even if no separate provenance
        # argument was supplied. Do not describe replays as external validation.
        matching=next((name for name,values in known.items() if row['inputs'] and set(row['inputs']).issubset(values)
                       and all(values[k]==v for k,v in row['inputs'].items())),None)
        is_demo=matching is not None
        if matching and not source:source=sources.get(matching,{})
        if row['name'] in known and not is_demo:
            # Renaming/reusing a candidate ID must not transfer source evidence
            # to modified parameters. Require fresh provenance for that design.
            source={}
        components=source.get('complete_lipid_identity','未提供完整材料结构；以输入及模型固定材料体系为准')
        if row['inputs'].get('headgroup_precursor')=='DLin-MC3-DMA':
            components='Haase固定MC3:DSPC:cholesterol:PEG-DMG=50:10:38.5:1.5 mol%; N/P=3; total lipid:mRNA=10:1 w/w'
        row['submission']=dict(track='赛道4',project_target='gBK靶向siRNA递送；当前预测为文献实验代理终点',
            components=components,
            source=source,selection_with_known_truth=bool(source.get('selection')) or is_demo,
            external_validation=False,run_version=RUN_VERSION)
    return records

def flattened(records):
    models={m['key']:m for m in catalog()['models']};out=[]
    references={m['key']:m.get('sources',[]) for m in read_json(ROOT/'models/evaluation-records.json')}
    for r in records:
        s=r.get('submission',{});source=s.get('source',{})
        composition=s.get('components','未提供完整材料结构')
        if source.get('formula_ratio'):composition+='; '+source['formula_ratio_order']+'='+source['formula_ratio']
        for key,p in r['predictions'].items():
            notes=list(p.get('notes',[]))
            if s.get('selection_with_known_truth'):notes.append('已结合文献真值筛选的既有候选回代；非盲外部验证。')
            notes.append('本课题gBK siRNA/糖基化新载体未获外部验证；mRNA表达不能等同siRNA沉默。')
            model_version=models[key]['version']
            if p.get('status')=='reference':model_version=(p.get('comparison_key') or '').split('|')[2]
            elif p.get('status')=='unavailable':model_version='无可用模型'
            out.append(dict(zip(HEADERS,[r['name'],s.get('track','赛道4'),composition,s.get('project_target','gBK靶向siRNA'),
                p['name'],p['endpoint'],'' if p.get('value') is None else format(p['value'],'.15g'),p.get('unit',''),
                model_version,RUN_VERSION,p.get('status','predicted'),p.get('comparison_key') or '',
                p.get('protocol',''),json.dumps(r['inputs'],ensure_ascii=False,sort_keys=True),p.get('doi') or source.get('doi') or ';'.join(references.get(key,[])),
                '是' if s.get('selection_with_known_truth') else '未进行盲验证','否','；'.join(notes)])))
    return out
