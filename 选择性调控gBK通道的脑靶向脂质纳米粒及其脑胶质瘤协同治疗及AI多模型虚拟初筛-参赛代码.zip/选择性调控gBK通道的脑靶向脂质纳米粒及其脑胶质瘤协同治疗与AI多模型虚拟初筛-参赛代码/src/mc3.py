"""MC3小样本条件参考模型：按终点、图版、固定配方分别拟合分段直线。

不训练原来的六个模型，不随机拆分重复孔，不生成虚假的独立配方R²。
荧光素酶：剂量采用log10(x)-log10(y)，时间采用x-log10(y)；
MTT：x-y线性插值。禁止超出观测范围；不是任意新MC3配方预测器。
只依赖Python标准库：python fit_mc3.py
"""
import csv
import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SPECS={
    'haase_expression_dose': ('dose_ng_per_well','log10','log10','n2a-delivery',24, None),
    'haase_expression_time': ('time_h','identity','log10','n2a-delivery',None,60),
    'haase_viability_dose': ('dose_ng_per_well','identity','identity','n2a-compatibility',24,None),
}

def transformed(value, kind):
    return math.log10(value) if kind=='log10' else value

def fit_curve(rows, x_transform, y_transform):
    points=sorted((float(r['x']),float(r['value'])) for r in rows)
    if len(points)<2 or len({x for x,_ in points})!=len(points):
        raise ValueError('每条曲线至少两个不同条件均值；不得堆叠重复孔。')
    segments=[]
    for (x0,y0),(x1,y1) in zip(points,points[1:]):
        a,b=transformed(x0,x_transform),transformed(x1,x_transform)
        c,d=transformed(y0,y_transform),transformed(y1,y_transform)
        slope=(d-c)/(b-a)
        segments.append(dict(lo=x0,hi=x1,slope=slope,intercept=c-slope*a))
    return dict(kind='bounded_piecewise_reference',x_transform=x_transform,
                y_transform=y_transform,minimum=points[0][0],maximum=points[-1][0],segments=segments)

def evaluate_curve(curve, x):
    if isinstance(x,bool) or not isinstance(x,(float,int)) or not math.isfinite(x):
        raise ValueError('输入必须是有限数值。')
    if not curve['minimum']<=x<=curve['maximum']:
        raise ValueError('不允许范围外外推。')
    seg=next(s for s in curve['segments'] if s['lo']<=x<=s['hi'])
    z=seg['slope']*transformed(x,curve['x_transform'])+seg['intercept']
    return 10**z if curve['y_transform']=='log10' else z
