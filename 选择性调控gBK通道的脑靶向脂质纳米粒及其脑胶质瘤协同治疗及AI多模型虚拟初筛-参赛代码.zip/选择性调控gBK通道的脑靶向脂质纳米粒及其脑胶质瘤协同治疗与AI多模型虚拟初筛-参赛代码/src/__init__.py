"""Portable wrappers and unchanged scientific model implementations."""
