"""完整推理调用层：六个既有权重 + MC3固定配方参考支路。

Python 3.10+，只用标准库，不修改/重训原模型。
网页用相同权重的JavaScript等价实现；此模块供Agent或Python后端导入。
示例: predict_batch({'models':['n2a-delivery','n2a-compatibility'],
 'formulations':[{'name':'MC3-20ng','inputs':{'headgroup_precursor':'DLin-MC3-DMA',
 'mc3_formulation':'haase-2024','mc3_mode':'dose-24h','mc3_dose_ng':20,'mc3_time_h':24}}]})
"""
import copy
import json
import math
import re
import struct
from pathlib import Path
from functools import lru_cache
from src.mc3 import evaluate_curve

ROOT=Path(__file__).resolve().parents[1]
DECIMAL=re.compile(r'^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$')

def condition_number(value):
    """保留输入浮点精度，避免两个接近的剂量被6位格式化合并。"""
    return str(int(value)) if float(value).is_integer() else str(value)

@lru_cache(maxsize=1)
def _artifacts():
    return tuple(json.loads((ROOT/'models'/name).read_text(encoding='utf8'))
                 for name in ['catalog.json','model-parameters.json'])

def catalog():
    """复制返回元数据，避免调用方修改全局范围或下拉选项。"""
    return copy.deepcopy(_artifacts()[0])

def _is_mc3(selected,inputs):
    c,_=_artifacts()
    return inputs.get('headgroup_precursor')=='DLin-MC3-DMA' and any(k in c['mc3']['bio_keys'] for k in selected)

def input_fields(selected,inputs=None):
    inputs=inputs or {};c,_=_artifacts();models={m['key']:m for m in c['models']}
    if (not isinstance(selected,list) or not selected or not all(isinstance(k,str) for k in selected)
        or len(selected)!=len(set(selected)) or any(k not in models for k in selected)):
        raise ValueError('请选择有效且不重复的模型。')
    mc3=_is_mc3(selected,inputs);merged={}
    for key in selected:
        m=models[key];fs=copy.deepcopy(m['fields'])
        if mc3:
            cfg=c['mc3']['fields'];fs=[f for f in fs if f['key']=='headgroup_precursor']
            def num(k,lo,hi):return dict(key=k,**cfg[k],minimum=lo,maximum=hi)
            if key in ['n2a-delivery','n2a-compatibility']:
                fs.append(dict(key='mc3_formulation',**cfg['mc3_formulation']))
            if key=='n2a-delivery':
                fs.append(dict(key='mc3_mode',**cfg['mc3_mode']))
                mode=inputs.get('mc3_mode','dose-24h')
                if mode=='dose-24h':fs.extend([num('mc3_dose_ng',3,30),num('mc3_time_h',24,24)])
                elif mode=='time-60ng':fs.extend([num('mc3_dose_ng',60,60),num('mc3_time_h',6,48)])
                else:raise ValueError('请选择MC3表达参考条件。')
            elif key=='n2a-compatibility':fs.extend([num('mc3_dose_ng',15,60),num('mc3_time_h',24,24)])
        elif key=='bbb-transport':
            ctx=m['contexts'].get(inputs.get('context'))
            if not ctx:raise ValueError('请选择BBB实验条件。')
            for k,(lo,hi) in ctx['ranges'].items():fs.append(dict(key=k,**c['fields'][k],type='number',minimum=lo,maximum=hi))
        for f in fs:
            k=f['key']
            if k not in merged:merged[k]=copy.deepcopy(f)
            elif f['type']=='number':
                merged[k]['minimum']=max(merged[k]['minimum'],f['minimum'])
                merged[k]['maximum']=min(merged[k]['maximum'],f['maximum'])
            else:merged[k]['options']=[o for o in merged[k]['options'] if any(o['value']==v['value'] for v in f['options'])]
    return merged

def validate_batch(payload):
    if not isinstance(payload,dict):raise ValueError('请求格式错误。')
    rows=payload.get('formulations');selected=payload.get('models');names=set();clean=[]
    if not isinstance(rows,list) or not 1<=len(rows)<=5:raise ValueError('每批1–5组配方。')
    for row in rows:
        if not isinstance(row,dict):raise ValueError('配方格式错误。')
        name=row.get('name');inp=row.get('inputs')
        if not isinstance(name,str) or not name.strip() or len(name)>60 or name.strip() in names:raise ValueError('编号需为1–60字符且不重复。')
        name=name.strip();names.add(name)
        if not isinstance(inp,dict):raise ValueError('参数格式错误。')
        fields=input_fields(selected,inp);values={}
        if set(inp)-set(fields):raise ValueError('包含所选模型不需要的参数。')
        for k,f in fields.items():
            x=inp.get(k)
            if f['type']=='select':
                if x not in [o['value'] for o in f['options']]:raise ValueError(f'{f["label"]}必须从下拉选择。')
            else:
                if isinstance(x,bool) or not isinstance(x,(int,float,str)):raise ValueError(f'{f["label"]}必须为数值。')
                if isinstance(x,str) and not DECIMAL.fullmatch(x.strip()):raise ValueError(f'{f["label"]}必须为数值。')
                x=float(x)
                if not math.isfinite(x) or not f['minimum']<=x<=f['maximum']:raise ValueError(f'{f["label"]}超出支持范围。')
            values[k]=x
        clean.append(dict(name=name,inputs=values))
    return dict(models=list(selected),formulations=clean)

def _legacy_value(key,inputs):
    """复用导出的参数；树输入float32行为与sklearn/JS适配器一致。"""
    c,parameters=_artifacts();m=next(m for m in c['models'] if m['key']==key);p=parameters[key]
    if p['kind']=='bbb_ridge':
        x=[(inputs[k]-p['mean'][i])/p['sd'][i] for i,k in enumerate(p['numeric'])]
        native=m['context_mapping'][inputs['context']]
        for levels in p['levels'].values():x.extend(float(native==v) for v in levels)
        z=(p['coef'][0]+sum(v*w for v,w in zip(x,p['coef'][1:])))*p['ysd']+p['ymean']
        return 100/(1+math.exp(-min(700,max(-700,z))))
    x=[]
    for i,feature in enumerate(p['feature_names']):
        if '=' in feature:
            k,v=feature.split('=',1);value=float(inputs[k]==v)
        else:value=float(inputs[feature])
        x.append((value-p['mean'][i])/p['scale'][i])
    if p['kind']=='ridge':value=p['intercept']+sum(v*w for v,w in zip(x,p['coef']))
    else:
        x=[struct.unpack('f',struct.pack('f',v))[0] for v in x];value=0
        for tree in p['trees']:
            i=0
            while tree['left'][i]!=-1:
                i=tree['left'][i] if x[tree['feature'][i]]<=tree['threshold'][i] else tree['right'][i]
            value+=tree['value'][i]
        value/=len(p['trees'])
    if p.get('transform')=='log1p':value=math.expm1(value)
    if not math.isfinite(value):raise ValueError('模型未返回有限数值。')
    return value

def _mc3_result(key,inp):
    c,p=_artifacts();m=next(m for m in c['models'] if m['key']==key)
    base=dict(name=m['name'],status='unavailable',value=None,unit='',endpoint='MC3：暂无可用终点模型',
        purpose='数据不足，不参与比较',meaning='没有这一终点的MC3配套训练数据，保留空值。',
        protocol='MC3专用支路；未用其他材料或细胞替代。',comparison_key=None,doi=None,source_type=None,
        notes=['不将缺失结果设为0、1或100。'])
    if key not in ['n2a-delivery','n2a-compatibility']:return base
    delivery=key=='n2a-delivery';timed=delivery and inp['mc3_mode']=='time-60ng'
    series=('haase_expression_time' if timed else 'haase_expression_dose') if delivery else 'haase_viability_dose'
    curve=p['mc3_reference'][series];x=inp['mc3_time_h'] if timed else inp['mc3_dose_ng']
    base.update(value=evaluate_curve(curve,x),unit=curve['unit'],status='reference',
        endpoint='MC3固定配方FLuc表达（扣除HBG背景）' if delivery else 'MC3固定配方MTT代谢活力（HBG归一化）',
        meaning='固定文献配方的区间内条件插值；不是新配方、多变量理化参数效应或脑递送预测。',
        purpose='固定配方条件参考，不用于新配方排名',
        protocol=f'Haase 2024；{curve["recipe"]}；N2a 10000 cells/well；FLuc mRNA {inp["mc3_dose_ng"]:g} ng/well；{inp["mc3_time_h"]:g} h；{curve["figure"]}。',
        comparison_key=f'MC3|{series}|{curve["version"]}|{condition_number(inp["mc3_dose_ng"])}|{condition_number(inp["mc3_time_h"])}',
        doi=curve['doi'],figure=curve['figure'],source_type=curve['source_type'],
        notes=['图表估读；仅1个独立配方，无跨配方验证。','不跨剂量、时间或检测定义进行载体排名。'])
    return base

def predict_batch(payload):
    """最多5组；返回null/None表示没有模型，不是零预测。"""
    clean=validate_batch(payload);c,_=_artifacts();models={m['key']:m for m in c['models']};out=[]
    for row in clean['formulations']:
        pred={};inp=row['inputs']
        for key in clean['models']:
            if _is_mc3(clean['models'],inp):pred[key]=_mc3_result(key,inp);continue
            m=models[key];value=_legacy_value(key,inp);protocol=m['protocol'];comparison=m['version']
            meaning={'lnp-size':'固定材料体系下的水动力学粒径，不代表粒径越小越好。','bbb-transport':'所选体外屏障的示踪物转运，不等同体内核酸跨脑效率。'}.get(key,
                '相对MC3的荧光素酶表达倍数，不是摄取率。' if 'delivery' in key else '相对PBS的MTT活力，可超过100%，不等同体内安全性。')
            if key=='bbb-transport':
                protocol=m['contexts'][inp['context']]['description']+f' 观察时间：{inp["time_h"]:g} h。'
                comparison+=f'|{inp["context"]}|{condition_number(inp["time_h"])}'
            notes=['既定文献材料和条件内的探索预测，未独立湿实验验证。']
            if 'compatibility' in key:notes.append('原记录实验剂量未核实。')
            if value<0:notes.append('结果低于物理下限，原值保留，不应自动采纳。')
            pred[key]=dict(value=value,unit=m['unit'],name=m['name'],endpoint=m['endpoint'],purpose=m['purpose'],status='predicted',
                meaning=meaning,protocol=protocol,comparison_key=comparison,notes=notes)
        out.append(dict(**row,selected_models=clean['models'],predictions=pred))
    return out

def predict_mc3_delivery(dose_ng=15,time_h=24,mode='dose-24h'):
    """独立表达参考接口。dose-24h:3–30ng且24h；time-60ng:60ng且6–48h。"""
    inputs=dict(headgroup_precursor='DLin-MC3-DMA',mc3_formulation='haase-2024',mc3_mode=mode,mc3_dose_ng=dose_ng,mc3_time_h=time_h)
    return predict_batch(dict(models=['n2a-delivery'],formulations=[dict(name='MC3',inputs=inputs)]))[0]['predictions']['n2a-delivery']

def predict_mc3_viability(dose_ng=30):
    """独立N2a MTT参考接口：15–60ng，24h，HBG参照。"""
    inputs=dict(headgroup_precursor='DLin-MC3-DMA',mc3_formulation='haase-2024',mc3_dose_ng=dose_ng,mc3_time_h=24)
    return predict_batch(dict(models=['n2a-compatibility'],formulations=[dict(name='MC3',inputs=inputs)]))[0]['predictions']['n2a-compatibility']

def sort_records(records,model,direction='desc'):
    c,_=_artifacts()
    if model not in [m['key'] for m in c['models']] or direction not in ['asc','desc']:raise ValueError('排序参数错误。')
    groups={};missing=[]
    for row in records:
        p=row.get('predictions',{}).get(model)
        if not p or p.get('value') is None:missing.append(row);continue
        groups.setdefault(p['comparison_key'],[]).append(row)
    result=[]
    for key,rows in sorted(groups.items()):
        rows.sort(key=lambda r:r['predictions'][model]['value'],reverse=direction=='desc')
        result.append(dict(protocol=rows[0]['predictions'][model]['protocol'],records=rows))
    return dict(groups=result,missing=missing)

if __name__=='__main__':
    print(json.dumps({'delivery_20ng':predict_mc3_delivery(20),'MTT_20ng':predict_mc3_viability(20)},ensure_ascii=False,indent=2,allow_nan=False))
